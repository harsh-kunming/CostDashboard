import json
import asyncio
import aiofiles
from datetime import datetime
from pathlib import Path
from typing import List, Dict
import logging
from models import UploadRecord

logger = logging.getLogger(__name__)

class FileService:
    def __init__(self):
        self.history_dir = Path("history")
        self.history_file = self.history_dir / "upload_history.json"
        self.history_dir.mkdir(exist_ok=True)
    
    async def load_upload_history(self) -> List[UploadRecord]:
        """Load upload history from JSON file asynchronously"""
        try:
            if self.history_file.exists():
                async with aiofiles.open(self.history_file, 'r') as f:
                    content = await f.read()
                    history_data = json.loads(content)
                    return [UploadRecord(**record) for record in history_data]
            return []
        except Exception as e:
            logger.error(f"Error loading upload history: {e}")
            return []
    
    async def save_upload_history(self, history: List[UploadRecord]):
        """Save upload history to JSON file asynchronously"""
        try:
            history_data = [record.dict() for record in history]
            async with aiofiles.open(self.history_file, 'w') as f:
                await f.write(json.dumps(history_data, indent=2))
        except Exception as e:
            logger.error(f"Error saving upload history: {e}")
            raise e
    
    async def add_to_upload_history(self, 
                                   filename: str, 
                                   file_size: int = None, 
                                   file_id: str = None) -> UploadRecord:
        """Add a new file to upload history, maintaining max 10 entries"""
        try:
            history = await self.load_upload_history()
            
            # Create new entry
            new_record = UploadRecord(
                filename=filename,
                upload_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                file_size=file_size,
                status="Processing",
                file_id=file_id
            )
            
            # Add to beginning of list
            history.insert(0, new_record)
            
            # Keep only last 10 entries
            history = history[:10]
            
            # Save updated history
            await self.save_upload_history(history)
            
            return new_record
            
        except Exception as e:
            logger.error(f"Error adding to upload history: {e}")
            raise e
    
    async def update_upload_status(self, file_id: str, status: str):
        """Update upload status for a specific file"""
        try:
            history = await self.load_upload_history()
            
            for record in history:
                if record.file_id == file_id:
                    record.status = status
                    break
            
            await self.save_upload_history(history)
            
        except Exception as e:
            logger.error(f"Error updating upload status: {e}")
    
    async def clear_upload_history(self):
        """Clear all upload history"""
        try:
            await self.save_upload_history([])
            logger.info("Upload history cleared")
        except Exception as e:
            logger.error(f"Error clearing upload history: {e}")
            raise e