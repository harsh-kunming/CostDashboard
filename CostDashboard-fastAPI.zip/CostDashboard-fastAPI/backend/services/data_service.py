import pandas as pd
import numpy as np
from typing import Dict, Optional, List, Tuple
from datetime import datetime
from pathlib import Path
import joblib
import logging
import asyncio
import aiofiles
from utils.constants import stock_bucket, month_map, color_map
from utils.data_utils import *

logger = logging.getLogger(__name__)

class DataService:
    def __init__(self):
        self.master_file_path = Path("src/kunmings.pkl")
        self.processing_status = {}
        
    async def initialize_master_dataset(self):
        """Initialize master dataset on startup"""
        try:
            if await self.check_master_dataset_exists():
                logger.info("Master dataset found and loaded")
            else:
                logger.info("No master dataset found")
        except Exception as e:
            logger.error(f"Error initializing master dataset: {e}")
    
    async def check_master_dataset_exists(self) -> bool:
        """Check if master dataset exists"""
        return self.master_file_path.exists()
    
    async def load_master_dataset(self) -> Optional[pd.DataFrame]:
        """Load master dataset asynchronously"""
        try:
            if await self.check_master_dataset_exists():
                loop = asyncio.get_event_loop()
                df = await loop.run_in_executor(None, pd.read_pickle, str(self.master_file_path))
                
                if df is not None and not df.empty:
                    if 'Product Id' in df.columns:
                        df['Product Id'] = df['Product Id'].astype(str)
                    # Apply consistent filters
                    df = apply_data_filters(df)
                    return df
            return pd.DataFrame()
        except Exception as e:
            logger.error(f"Error loading master dataset: {e}")
            return pd.DataFrame()
    
    async def save_master_dataset(self, df: pd.DataFrame):
        """Save master dataset asynchronously"""
        try:
            # Apply filters before saving
            df = apply_data_filters(df)
            
            # Create src directory if it doesn't exist
            Path("src").mkdir(exist_ok=True)
            
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, df.to_pickle, str(self.master_file_path))
            logger.info("Master dataset saved successfully")
        except Exception as e:
            logger.error(f"Error saving master dataset: {e}")
            raise e
    
    async def load_excel_file(self, file_path: Path) -> Dict:
        """Load Excel file asynchronously"""
        try:
            loop = asyncio.get_event_loop()
            df_dict = await loop.run_in_executor(None, pd.read_excel, str(file_path), None)
            
            # Process each sheet
            processed_dict = {}
            for sheet_name, df in df_dict.items():
                if df is not None and not df.empty:
                    if 'Product Id' in df.columns:
                        df['Product Id'] = df['Product Id'].astype(str)
                    processed_dict[sheet_name] = df
            
            return processed_dict
        except Exception as e:
            logger.error(f"Error loading Excel file: {e}")
            raise e
    
    async def process_uploaded_file(self, file_path: Path, file_id: str):
        """Process uploaded file in background"""
        try:
            self.processing_status[file_id] = {"status": "processing", "progress": 0}
            
            # Load Excel file
            df_dict = await self.load_excel_file(file_path)
            self.processing_status[file_id]["progress"] = 20
            
            # Validate required sheets
            required_sheets = ['Monthly Stock Data', 'Buying Max Prices', 'MIN Data', 'MAX Data', 'Min Selling Price']
            for sheet in required_sheets:
                if sheet not in df_dict:
                    raise ValueError(f"Required sheet '{sheet}' not found in uploaded file")
            
            self.processing_status[file_id]["progress"] = 40
            
            # Process the monthly stock sheet
            loop = asyncio.get_event_loop()
            processed_df = await loop.run_in_executor(
                None, self._populate_monthly_stock_sheet, df_dict
            )
            
            self.processing_status[file_id]["progress"] = 70
            
            # Load existing master dataset
            existing_df = await self.load_master_dataset()
            
            # Combine with existing data
            if existing_df is not None and not existing_df.empty:
                master_df = pd.concat([processed_df, existing_df], ignore_index=True, axis=0)
            else:
                master_df = processed_df
            
            # Remove duplicates and apply filters
            cols = master_df.columns.tolist()
            master_df = master_df.groupby(['Product Id', 'Year', 'Month']).first().reset_index().loc[:, cols]
            master_df = apply_data_filters(master_df)
            
            self.processing_status[file_id]["progress"] = 90
            
            # Save master dataset
            await self.save_master_dataset(master_df)
            
            self.processing_status[file_id] = {"status": "completed", "progress": 100}
            
            # Clean up uploaded file
            if file_path.exists():
                file_path.unlink()
                
        except Exception as e:
            logger.error(f"Error processing file {file_id}: {e}")
            self.processing_status[file_id] = {"status": "failed", "error": str(e)}
    
    def _populate_monthly_stock_sheet(self, df_dict: Dict) -> pd.DataFrame:
        """Process monthly stock sheet (synchronous helper)"""
        try:
            df_stock = df_dict['Monthly Stock Data']
            if 'avg' in df_stock.columns:
                df_stock.rename(columns={'avg': 'Avg Cost Total'}, inplace=True)
            
            df_buying = df_dict['Buying Max Prices']
            df_min_qty = df_dict['MIN Data']
            df_max_qty = df_dict['MAX Data']
            df_min_sp = df_dict['Min Selling Price']
            
            # Update quantity dictionaries
            update_max_qty(df_min_qty, 'min_qty.pkl')
            update_max_qty(df_max_qty, 'max_qty.pkl')
            update_max_qty(df_buying, 'max_buy.pkl')
            
            # Process data step by step
            df_stock = create_date_join(df_stock)
            df_stock = populate_quarter(df_stock)
            df_stock = calculate_avg(df_stock)
            df_stock = create_bucket(df_stock)
            df_stock = create_color_key(df_stock, color_map)
            df_stock['Shape key'] = df_stock['Shape'].apply(create_shape_key)
            df_stock = populate_max_qty(df_max_qty, df_stock)
            df_stock = populate_min_qty(df_min_qty, df_stock)
            df_stock = populate_buying_prices(df_buying, df_stock)
            df_stock = calculate_buying_price_avg(df_stock)
            df_stock = populate_selling_prices(df_min_sp, df_stock)
            
            # Apply filters and clean data
            df_stock = apply_data_filters(df_stock)
            df_stock.fillna(0, inplace=True)
            
            # Group by product, year, month
            cols = df_stock.columns.tolist()
            df_stock = df_stock.groupby(['Product Id', 'Year', 'Month']).first().reset_index().loc[:, cols]
            
            return df_stock
            
        except Exception as e:
            logger.error(f"Error processing monthly stock sheet: {e}")
            raise e
    
    async def get_processing_status(self, file_id: str) -> dict:
        """Get processing status for a file"""
        return self.processing_status.get(file_id, {"status": "not_found"})
    
    async def get_data_with_filters(self, 
                                  month: Optional[str] = None,
                                  year: Optional[int] = None,
                                  shape: Optional[str] = None,
                                  color: Optional[str] = None,
                                  bucket: Optional[str] = None) -> pd.DataFrame:
        """Get data with applied filters"""
        try:
            df = await self.load_master_dataset()
            if df is None or df.empty:
                return pd.DataFrame()
            
            # Apply filters
            if month:
                df = df[df['Month'] == month]
            if year:
                df = df[df['Year'] == year]
            if shape:
                df = df[df['Shape key'] == shape]
            if color:
                df = df[df['Color Key'] == color]
            if bucket:
                df = df[df['Buckets'] == bucket]
            
            return df
        except Exception as e:
            logger.error(f"Error getting filtered data: {e}")
            return pd.DataFrame()