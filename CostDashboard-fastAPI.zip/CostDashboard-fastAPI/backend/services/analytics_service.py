import pandas as pd
import numpy as np
from typing import Dict, Optional, List, Tuple, Any
import logging
import asyncio
import joblib
from pathlib import Path
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from utils.constants import stock_bucket, month_map, color_map
from utils.data_utils import *
from services.data_service import DataService

logger = logging.getLogger(__name__)

class AnalyticsService:
    def __init__(self):
        self.data_service = DataService()
    
    async def get_filtered_data(self, 
                               filter_month: Optional[str],
                               filter_year: Optional[int], 
                               filter_shape: Optional[str],
                               filter_color: Optional[str], 
                               filter_bucket: Optional[str]) -> Tuple:
        """Get filtered data with enhanced error handling"""
        try:
            master_df = await self.data_service.load_master_dataset()
            
            if master_df is None or master_df.empty:
                return [pd.DataFrame(), "No master data available", "No master data available", 0, 0]
            
            # Apply consistent filters
            master_df = apply_data_filters(master_df)
            
            cols = master_df.columns.tolist()
            master_df = master_df.groupby(['Product Id', 'Year', 'Month']).first().reset_index().loc[:, cols]
            
            if isinstance(filter_year, str) and filter_year.isnumeric():
                filter_year = int(filter_year)
            
            filter_data = master_df[
                (master_df['Month'] == filter_month) & 
                (master_df['Year'] == filter_year) & 
                (master_df['Shape key'] == filter_shape) &
                (master_df['Color Key'] == filter_color) &
                (master_df['Buckets'] == filter_bucket)
            ]
            
            max_qty = filter_data['Max Qty'].max() if not filter_data.empty else 0
            min_qty = filter_data['Min Qty'].min() if not filter_data.empty else 0
            stock_in_hand = filter_data.shape[0]
            
            if stock_in_hand == 0:
                try:
                    max_qty_dict = joblib.load('src/max_qty.pkl')
                    min_qty_dict = joblib.load('src/min_qty.pkl')
                    max_buy_dict = joblib.load('src/max_buy.pkl')
                    filter_shape_color = f"{filter_shape}_{filter_color}"
                    
                    if filter_shape_color in max_qty_dict:
                        latest_month_max = list(max_qty_dict[filter_shape_color].keys())[-1]
                        max_qty = max_qty_dict[filter_shape_color][latest_month_max].get(filter_bucket, 0)
                    
                    if filter_shape_color in min_qty_dict:
                        latest_month_min = list(min_qty_dict[filter_shape_color].keys())[-1]
                        min_qty = min_qty_dict[filter_shape_color][latest_month_min].get(filter_bucket, 0)
                    
                    if filter_shape_color in max_buy_dict:
                        latest_month_min = list(max_buy_dict[filter_shape_color].keys())[-1]
                        max_buying_price = max_buy_dict[filter_shape_color][latest_month_min].get(filter_bucket, 0)
                except Exception as e:
                    logger.error(f"Error loading qty dictionaries: {e}")
                    max_qty, min_qty, max_buying_price = 0, 0, 0
            
            gap_analysis_op = gap_analysis(max_qty, min_qty, stock_in_hand)
            
            if not filter_data.empty:
                max_buying_price = filter_data['Max Buying Price'].max()
                weight_sum = filter_data['Weight'].sum()
                current_avg_cost = safe_divide(filter_data['Avg Cost Total'].sum(), weight_sum, 0) * 0.9
                min_selling_price = filter_data['Min Selling Price'].min()
                
                return [filter_data, int(max_buying_price), int(current_avg_cost), gap_analysis_op, min_selling_price]
            else:
                empty_df = pd.DataFrame(columns=master_df.columns.tolist())
                return [empty_df, int(max_buying_price), f"No data for filters", gap_analysis_op, 0]
                
        except Exception as e:
            logger.error(f"Error getting filtered data: {e}")
            empty_df = pd.DataFrame()
            return [empty_df, "Error processing data", "Error processing data", 0, 0]
    
    async def get_summary_metrics(self, 
                                 filter_data: pd.DataFrame,
                                 filter_month: str, 
                                 filter_shape: str,
                                 filter_year: int, 
                                 filter_color: str, 
                                 filter_bucket: str,
                                 filter_monthly_var_col: str) -> List[float]:
        """Get summary metrics with comprehensive error handling"""
        try:
            filter_year = int(filter_year)
            master_df = await self.data_service.load_master_dataset()
            
            # Apply consistent filters
            master_df = apply_data_filters(master_df)
            filter_data = apply_data_filters(filter_data)

            if master_df is None or master_df.empty:
                return [0, 0, 0]
            
            cols = master_df.columns.tolist()
            master_df = master_df.groupby(['Product Id', 'Year', 'Month']).first().reset_index().loc[:, cols]
            
            _filter_ = master_df[
                (master_df['Shape key'] == filter_shape) &
                (master_df['Color Key'] == filter_color) &
                (master_df['Buckets'] == filter_bucket)
            ]
            
            if _filter_.empty:
                return [0, 0, 0]
            
            # Calculate previous month
            current_month_num = month_map.get(filter_month, 1)
            prev_month_name = None
            prev_year = filter_year
            
            if current_month_num == 1:
                prev_month_name = 'December'
                prev_year = filter_year - 1
            else:
                for month_name, month_num in month_map.items():
                    if month_num == current_month_num - 1:
                        prev_month_name = month_name
                        break
            
            prev_filter_data = master_df[
                (master_df['Month'] == prev_month_name) & 
                (master_df['Year'] == prev_year) & 
                (master_df['Shape key'] == filter_shape) &
                (master_df['Color Key'] == filter_color) &
                (master_df['Buckets'] == filter_bucket)
            ]
            
            if filter_monthly_var_col == 'Current Average Cost':
                variance_col = 'Buying Price Avg'
            elif filter_monthly_var_col in ['Max Buying Price', 'Min Selling Price']:
                variance_col = filter_monthly_var_col
            else:
                variance_col = 'Max Buying Price'
            
            # Calculate variance metrics
            var_analysis = monthly_variance(_filter_, variance_col)
            
            if var_analysis.empty:
                return [0, 0, 0]
            
            # Get MOM metrics
            current_analysis = var_analysis[
                (var_analysis['Month'] == filter_month) & 
                (var_analysis['Year'] == filter_year)
            ]
            
            if not current_analysis.empty:
                mom_percent_change = current_analysis['Monthly_change'].iloc[0]
                mom_qoq_percent_change = current_analysis['qaurter_change'].iloc[0]
            else:
                mom_percent_change = 0
                mom_qoq_percent_change = 0
            
            # Calculate MOM Variance
            if filter_monthly_var_col == 'Current Average Cost':
                if not filter_data.empty and not prev_filter_data.empty:
                    weight_sum_current = filter_data['Weight'].sum()
                    weight_sum_prev = prev_filter_data['Weight'].sum()
                    
                    current_avg_cost = safe_divide(filter_data['Avg Cost Total'].sum(), weight_sum_current, 0) * 0.9
                    prev_current_avg_cost = safe_divide(prev_filter_data['Avg Cost Total'].sum(), weight_sum_prev, 0) * 0.9
                    
                    mom_variance = safe_divide((current_avg_cost - prev_current_avg_cost), prev_current_avg_cost, 0) * 100
                else:
                    mom_variance = 0
            else:
                if not filter_data.empty and variance_col in filter_data.columns:
                    avg_value = _filter_[variance_col].mean()
                    if avg_value != 0:
                        deviations = (filter_data[variance_col] - avg_value) / avg_value
                        mom_variance = (deviations.sum() / len(filter_data)) * 100 if len(filter_data) > 0 else 0
                    else:
                        mom_variance = 0
                else:
                    mom_variance = 0
            
            # Clean up infinite or NaN values
            mom_variance = 0 if pd.isna(mom_variance) or np.isinf(mom_variance) else mom_variance
            mom_percent_change = 0 if pd.isna(mom_percent_change) or np.isinf(mom_percent_change) else mom_percent_change
            mom_qoq_percent_change = 0 if pd.isna(mom_qoq_percent_change) or np.isinf(mom_qoq_percent_change) else mom_qoq_percent_change
            
            return [round(mom_variance, 2), round(mom_percent_change, 2), round(mom_qoq_percent_change, 2)]
            
        except Exception as e:
            logger.error(f"Error getting summary metrics: {e}")
            return [0, 0, 0]
    
    async def create_trend_visualization(self, 
                                        selected_shape: Optional[str] = None,
                                        selected_color: Optional[str] = None, 
                                        selected_bucket: Optional[str] = None,
                                        selected_variance_column: Optional[str] = None,
                                        selected_month: Optional[str] = None, 
                                        selected_year: Optional[int] = None) -> Dict[str, Any]:
        """Create trend line visualizations data"""
        try:
            master_df = await self.data_service.load_master_dataset()
            
            if master_df is None or master_df.empty:
                return {"error": "No data available"}
            
            # Apply consistent filters
            master_df = apply_data_filters(master_df)
            
            # Filter data based on selections
            filtered_df = master_df.copy()
            title_parts = []
            
            if selected_shape:
                filtered_df = filtered_df[filtered_df['Shape key'] == selected_shape]
                title_parts.append(selected_shape)
            if selected_color:
                filtered_df = filtered_df[filtered_df['Color Key'] == selected_color]
                title_parts.append(selected_color)
            if selected_bucket:
                filtered_df = filtered_df[filtered_df['Buckets'] == selected_bucket]
                title_parts.append(selected_bucket)
            
            title_suffix = " | ".join(title_parts) if title_parts else "All Data"
            
            if filtered_df.empty:
                return {"error": "No data available for selected filters"}
            
            # Prepare variance column
            variance_col = selected_variance_column
            if variance_col == 'Current Average Cost':
                variance_col = 'Buying Price Avg'
            elif not variance_col:
                variance_col = 'Max Buying Price'
            
            if variance_col not in filtered_df.columns:
                return {"error": f"Column '{variance_col}' not found in data"}
            
            # Calculate monthly variance data
            var_analysis = monthly_variance(filtered_df, variance_col)
            
            if var_analysis.empty:
                return {"error": "No variance data available for analysis"}
            
            # Create date column for proper sorting
            var_analysis['Date'] = pd.to_datetime(
                '01-' + var_analysis['Num_Month'].astype(str) + '-' + var_analysis['Year'].astype(str), 
                format='%d-%m-%Y',
                errors='coerce'
            )
            var_analysis = var_analysis.dropna(subset=['Date']).sort_values('Date')
            
            if var_analysis.empty:
                return {"error": "No valid date data for visualization"}
            
            # Filter data up to selected month/year if specified
            if selected_month and selected_year:
                try:
                    selected_month_num = month_map.get(selected_month, 0)
                    cutoff_date = pd.to_datetime(f"{selected_year}-{selected_month_num:02d}-01")
                    var_analysis_filtered = var_analysis[var_analysis['Date'] <= cutoff_date].copy()
                    
                    var_analysis_filtered['is_selected'] = (
                        (var_analysis_filtered['Month'] == selected_month) & 
                        (var_analysis_filtered['Year'] == selected_year)
                    )
                except Exception:
                    var_analysis_filtered = var_analysis.copy()
                    var_analysis_filtered['is_selected'] = False
            else:
                var_analysis_filtered = var_analysis.copy()
                var_analysis_filtered['is_selected'] = False
            
            # Prepare chart data
            chart_data = {
                "title": f"Trend Analysis - {title_suffix}",
                "data": var_analysis_filtered.to_dict('records'),
                "has_data": not var_analysis_filtered.empty
            }
            
            return chart_data
            
        except Exception as e:
            logger.error(f"Error creating trend visualization: {e}")
            return {"error": f"Error creating visualization: {str(e)}"}
    
    async def create_summary_charts(self, 
                                   selected_shape: Optional[str] = None,
                                   selected_color: Optional[str] = None, 
                                   selected_bucket: Optional[str] = None,
                                   selected_month: Optional[str] = None, 
                                   selected_year: Optional[int] = None) -> Dict[str, Any]:
        """Create summary charts data"""
        try:
            master_df = await self.data_service.load_master_dataset()
            
            if master_df is None or master_df.empty:
                return {"error": "No data available"}
            
            # Apply consistent filters
            master_df = apply_data_filters(master_df)
            
            # Group data first to avoid duplicates
            cols = master_df.columns.tolist()
            master_df_grouped = master_df.groupby(['Product Id', 'Year', 'Month']).first().reset_index().loc[:, cols]
            
            # Filter data based on selections
            filtered_df = master_df_grouped.copy()
            title_parts = []
            
            if selected_shape:
                filtered_df = filtered_df[filtered_df['Shape key'] == selected_shape]
                title_parts.append(selected_shape)
            if selected_color:
                filtered_df = filtered_df[filtered_df['Color Key'] == selected_color]
                title_parts.append(selected_color)
            if selected_bucket:
                filtered_df = filtered_df[filtered_df['Buckets'] == selected_bucket]
                title_parts.append(selected_bucket)
            
            title_suffix = " | ".join(title_parts) if title_parts else "All Data"
            
            if filtered_df.empty:
                return {"error": "No data available for selected filters"}
            
            # Check if required columns exist
            required_cols = ['Avg Cost Total', 'Max Buying Price', 'Weight', 'Product Id', 'Month', 'Year']
            missing_cols = [col for col in required_cols if col not in filtered_df.columns]
            
            if missing_cols:
                return {"error": f"Missing required columns: {', '.join(missing_cols)}"}
            
            # Group by month and year to get summary statistics
            summary_data = filtered_df.groupby(['Month', 'Year']).agg({
                'Avg Cost Total': 'mean',
                'Max Buying Price': 'mean',
                'Weight': 'sum',
                'Product Id': 'count'
            }).reset_index()
            
            if summary_data.empty:
                return {"error": "No summary data available after grouping"}
            
            # Create date column for proper sorting
            summary_data['Num_Month'] = summary_data['Month'].map(month_map)
            summary_data = summary_data.dropna(subset=['Num_Month'])
            
            if summary_data.empty:
                return {"error": "No valid month data found"}
            
            summary_data['Date'] = pd.to_datetime(
                '01-' + summary_data['Num_Month'].astype(int).astype(str) + '-' + summary_data['Year'].astype(str), 
                format='%d-%m-%Y',
                errors='coerce'
            )
            
            summary_data = summary_data.dropna(subset=['Date']).sort_values('Date')
            
            if summary_data.empty:
                return {"error": "No valid date data for visualization"}
            
            # Filter data up to selected month/year if specified
            if selected_month and selected_year:
                try:
                    selected_month_num = month_map.get(selected_month, 0)
                    if selected_month_num > 0:
                        cutoff_date = pd.to_datetime(f"{selected_year}-{selected_month_num:02d}-01")
                        summary_data_filtered = summary_data[summary_data['Date'] <= cutoff_date].copy()
                        
                        summary_data_filtered['is_selected'] = (
                            (summary_data_filtered['Month'] == selected_month) & 
                            (summary_data_filtered['Year'] == selected_year)
                        )
                    else:
                        summary_data_filtered = summary_data.copy()
                        summary_data_filtered['is_selected'] = False
                except Exception:
                    summary_data_filtered = summary_data.copy()
                    summary_data_filtered['is_selected'] = False
            else:
                summary_data_filtered = summary_data.copy()
                summary_data_filtered['is_selected'] = False
            
            # Prepare chart data
            chart_data = {
                "title": f"Summary Analytics - {title_suffix}",
                "data": summary_data_filtered.to_dict('records'),
                "has_data": not summary_data_filtered.empty
            }
            
            return chart_data
            
        except Exception as e:
            logger.error(f"Error creating summary charts: {e}")
            return {"error": f"Error creating summary visualization: {str(e)}"}
    
    async def get_gap_summary_table(self, 
                                   selected_month: Optional[str],
                                   selected_year: Optional[int], 
                                   selected_shape: Optional[str],
                                   selected_color: Optional[str], 
                                   selected_bucket: Optional[str]) -> pd.DataFrame:
        """Generate GAP summary table with enhanced error handling"""
        try:
            master_df = await self.data_service.load_master_dataset()
            
            if master_df is None or master_df.empty:
                return pd.DataFrame()
            
            # Apply consistent filters
            master_df = apply_data_filters(master_df)
            
            gap_summary = []
            
            # Get unique values for each filter
            months = [selected_month] if selected_month else list(master_df['Month'].unique())
            years = [selected_year] if selected_year else list(master_df['Year'].unique())
            shapes = [selected_shape] if selected_shape else list(master_df['Shape key'].unique())
            colors = [selected_color] if selected_color else list(master_df['Color Key'].unique())
            buckets = [selected_bucket] if selected_bucket else list(master_df['Buckets'].unique())
            
            # Generate all combinations
            for month in months:
                for year in years:
                    for shape in shapes:
                        for color in colors:
                            for bucket in buckets:
                                try:
                                    # Filter data for current combination
                                    filtered_data = master_df[
                                        (master_df['Month'] == month) & 
                                        (master_df['Year'] == year) & 
                                        (master_df['Shape key'] == shape) & 
                                        (master_df['Color Key'] == color) & 
                                        (master_df['Buckets'] == bucket)
                                    ]
                                    
                                    if not filtered_data.empty:
                                        max_qty = int(filtered_data['Max Qty'].max())
                                        min_qty = int(filtered_data['Min Qty'].min())
                                        stock_in_hand = filtered_data.shape[0]
                                        gap_value = gap_analysis(max_qty, min_qty, stock_in_hand)
                                        min_selling_price = int(filtered_data['Min Selling Price'].max())
                                        max_buying_price = int(filtered_data['Max Buying Price'].max())
                                        
                                        gap_summary.append({
                                            'Month': month,
                                            'Year': year,
                                            'Shape': shape,
                                            'Color': color,
                                            'Bucket': bucket,
                                            'Max Qty': max_qty,
                                            'Min Qty': min_qty,
                                            'Stock in Hand': stock_in_hand,
                                            'GAP Value': int(gap_value),
                                            'Status': 'Excess' if gap_value > 0 else 'Need' if gap_value < 0 else 'Adequate',
                                            'Min Selling Price': min_selling_price,
                                            'Max Buying Price': max_buying_price
                                        })
                                    else:
                                        # Try to get from saved dictionaries
                                        try:
                                            max_qty_dict = joblib.load("src/max_qty.pkl")
                                            min_qty_dict = joblib.load('src/min_qty.pkl')
                                            max_buy_dict = joblib.load('src/max_buy.pkl')
                                            filter_shape_color = f"{shape}_{color}"
                                            
                                            max_qty = 0
                                            min_qty = 0
                                            max_buy = 0
                                            
                                            if filter_shape_color in max_qty_dict:
                                                latest_month = list(max_qty_dict[filter_shape_color].keys())[-1]
                                                max_qty = max_qty_dict[filter_shape_color][latest_month].get(bucket, 0)
                                            
                                            if filter_shape_color in min_qty_dict:
                                                latest_month = list(min_qty_dict[filter_shape_color].keys())[-1]
                                                min_qty = min_qty_dict[filter_shape_color][latest_month].get(bucket, 0)
                                            
                                            if filter_shape_color in max_buy_dict:
                                                latest_month = list(max_buy_dict[filter_shape_color].keys())[-1]
                                                max_buy = max_buy_dict[filter_shape_color][latest_month].get(bucket, 0)
                                                
                                            gap_value = gap_analysis(max_qty, min_qty, 0)
                                            
                                            gap_summary.append({
                                                'Month': month,
                                                'Year': year,
                                                'Shape': shape,
                                                'Color': color,
                                                'Bucket': bucket,
                                                'Max Qty': max_qty,
                                                'Min Qty': min_qty,
                                                'Stock in Hand': 0,
                                                'GAP Value': int(gap_value),
                                                'Status': 'Excess' if gap_value > 0 else 'Need' if gap_value < 0 else 'Adequate',
                                                'Max Buying Price': max_buy,
                                                'Min Selling Price': 0
                                            })
                                        except Exception as e2:
                                            logger.error(f"Error loading qty dictionaries for {shape}_{color}: {e2}")
                                            continue
                                            
                                except Exception as e:
                                    logger.error(f"Error processing gap summary for {month}-{year}-{shape}-{color}-{bucket}: {e}")
                                    continue
            
            if gap_summary:
                return pd.DataFrame(gap_summary).sort_values(by=['Shape', 'Color', 'Bucket'])
            else:
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error generating gap summary table: {e}")
            return pd.DataFrame()