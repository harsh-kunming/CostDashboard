from fastapi import FastAPI, File, UploadFile, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
from typing import Dict, Optional, List, Any, Union
from datetime import datetime
import io
import json
import os
from pathlib import Path
import joblib
import logging
import asyncio
import aiofiles
from pydantic import BaseModel, Field
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import uuid

# Local imports
from models import *
from services.data_service import DataService
from services.analytics_service import AnalyticsService
from services.file_service import FileService
from utils.constants import stock_bucket, month_map, color_map

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Yellow Diamond Dashboard API",
    description="API for Yellow Diamond inventory management and analytics",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
# app.mount("/static", StaticFiles(directory="static"), name="static")

# Services
data_service = DataService()
analytics_service = AnalyticsService()
file_service = FileService()

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    try:
        # Create necessary directories
        Path("src").mkdir(exist_ok=True)
        Path("history").mkdir(exist_ok=True)
        Path("uploads").mkdir(exist_ok=True)
        Path("static").mkdir(exist_ok=True)
        
        # Initialize master dataset if it exists
        await data_service.initialize_master_dataset()
        logger.info("Application initialized successfully")
    except Exception as e:
        logger.error(f"Error during startup: {e}")

@app.get("/")
async def read_root():
    """Health check endpoint"""
    return {"status": "ok", "message": "Yellow Diamond Dashboard API"}

@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    try:
        master_exists = await data_service.check_master_dataset_exists()
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "master_dataset_exists": master_exists
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"status": "unhealthy", "error": str(e)}
        )

@app.post("/api/upload", response_model=UploadResponse)
async def upload_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...)
):
    """Upload and process Excel file"""
    try:
        if not file.filename.endswith(('.xlsx', '.xls')):
            raise HTTPException(status_code=400, detail="Only Excel files are allowed")
        
        # Generate unique filename
        file_id = str(uuid.uuid4())
        file_path = Path("uploads") / f"{file_id}_{file.filename}"
        
        # Save uploaded file
        async with aiofiles.open(file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        # Add to upload history
        upload_record = await file_service.add_to_upload_history(
            filename=file.filename,
            file_size=len(content),
            file_id=file_id
        )
        
        # Process file in background
        background_tasks.add_task(
            data_service.process_uploaded_file, 
            file_path, 
            file_id
        )
        
        return UploadResponse(
            success=True,
            message=f"File {file.filename} uploaded successfully",
            file_id=file_id,
            upload_record=upload_record
        )
        
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/upload/status/{file_id}")
async def get_upload_status(file_id: str):
    """Check upload processing status"""
    try:
        status = await data_service.get_processing_status(file_id)
        return {"file_id": file_id, "status": status}
    except Exception as e:
        logger.error(f"Error getting upload status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/history", response_model=List[UploadRecord])
async def get_upload_history():
    """Get upload history"""
    try:
        return await file_service.load_upload_history()
    except Exception as e:
        logger.error(f"Error getting upload history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/history")
async def clear_upload_history():
    """Clear upload history"""
    try:
        await file_service.clear_upload_history()
        return {"message": "Upload history cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing upload history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/master/status")
async def get_master_status():
    """Get master dataset status"""
    try:
        exists = await data_service.check_master_dataset_exists()
        if exists:
            df = await data_service.load_master_dataset()
            return {
                "exists": True,
                "record_count": len(df) if df is not None else 0
            }
        return {"exists": False, "record_count": 0}
    except Exception as e:
        logger.error(f"Error getting master status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/filters")
async def get_available_filters():
    """Get available filter options"""
    try:
        df = await data_service.load_master_dataset()
        if df is None or df.empty:
            return FilterOptions()
        
        return FilterOptions(
            months=sorted(df['Month'].unique().tolist()) if 'Month' in df.columns else [],
            years=sorted(df['Year'].unique().tolist()) if 'Year' in df.columns else [],
            shapes=sorted(df['Shape key'].unique().tolist()) if 'Shape key' in df.columns else [],
            colors=['WXYZ', 'FLY', 'FY', 'FIY', 'FVY'],
            buckets=list(stock_bucket.keys()),
            variance_columns=['Current Average Cost', 'Max Buying Price', 'Min Selling Price']
        )
    except Exception as e:
        logger.error(f"Error getting filter options: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/data/filtered", response_model=FilteredDataResponse)
async def get_filtered_data(filters: DataFilters):
    """Get filtered data based on provided filters"""
    try:
        result = await analytics_service.get_filtered_data(
            filters.month, filters.year, filters.shape, 
            filters.color, filters.bucket
        )
        
        filter_data, max_buying_price, current_avg_cost, gap_output, min_selling_price = result
        
        return FilteredDataResponse(
            data=filter_data.to_dict('records') if not filter_data.empty else [],
            max_buying_price=max_buying_price,
            current_avg_cost=current_avg_cost,
            gap_analysis=gap_output,
            min_selling_price=min_selling_price,
            record_count=len(filter_data)
        )
    except Exception as e:
        logger.error(f"Error getting filtered data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analytics/summary", response_model=SummaryMetrics)
async def get_summary_metrics(request: SummaryRequest):
    """Get summary analytics metrics"""
    try:
        # Get filtered data first
        filtered_result = await analytics_service.get_filtered_data(
            request.filters.month, request.filters.year, request.filters.shape,
            request.filters.color, request.filters.bucket
        )
        
        filter_data = filtered_result[0]
        
        # Calculate summary metrics
        metrics = await analytics_service.get_summary_metrics(
            filter_data, request.filters.month, request.filters.shape,
            request.filters.year, request.filters.color, request.filters.bucket,
            request.variance_column
        )
        
        return SummaryMetrics(
            mom_variance=metrics[0],
            mom_percent_change=metrics[1],
            mom_qoq_percent_change=metrics[2]
        )
    except Exception as e:
        logger.error(f"Error calculating summary metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analytics/trend")
async def get_trend_analysis(request: TrendAnalysisRequest):
    """Get trend analysis data"""
    try:
        chart_data = await analytics_service.create_trend_visualization(
            request.shape, request.color, request.bucket,
            request.variance_column, request.month, request.year
        )
        return {"chart_data": chart_data}
    except Exception as e:
        logger.error(f"Error creating trend analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analytics/summary-charts")
async def get_summary_charts(request: TrendAnalysisRequest):
    """Get summary charts data"""
    try:
        chart_data = await analytics_service.create_summary_charts(
            request.shape, request.color, request.bucket,
            request.month, request.year
        )
        return {"chart_data": chart_data}
    except Exception as e:
        logger.error(f"Error creating summary charts: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analytics/gap-summary", response_model=List[GapSummaryRecord])
async def get_gap_summary(request: GapSummaryRequest):
    """Get GAP analysis summary"""
    try:
        gap_summary = await analytics_service.get_gap_summary_table(
            request.month, request.year, request.shape,
            request.color, request.bucket
        )
        
        return gap_summary.to_dict('records') if not gap_summary.empty else []
    except Exception as e:
        logger.error(f"Error getting GAP summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/download/csv")
async def download_csv(request: DownloadRequest):
    """Download filtered data as CSV"""
    try:
        if request.data_type == "filtered":
            result = await analytics_service.get_filtered_data(
                request.filters.month, request.filters.year, request.filters.shape,
                request.filters.color, request.filters.bucket
            )
            df = result[0]
        elif request.data_type == "master":
            df = await data_service.load_master_dataset()
        elif request.data_type == "gap":
            df = await analytics_service.get_gap_summary_table(
                request.filters.month, request.filters.year, request.filters.shape,
                request.filters.color, request.filters.bucket
            )
        else:
            raise HTTPException(status_code=400, detail="Invalid data type")
        
        if df is None or df.empty:
            raise HTTPException(status_code=404, detail="No data available")
        
        # Convert to CSV
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_content = csv_buffer.getvalue()
        
        # Create filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{request.data_type}_data_{timestamp}.csv"
        
        return StreamingResponse(
            io.BytesIO(csv_content.encode()),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        logger.error(f"Error downloading CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/aggregated-metrics")
async def get_aggregated_metrics(
    month: Optional[str] = None,
    year: Optional[int] = None,
    shape: Optional[str] = None,
    color: Optional[str] = None,
    bucket: Optional[str] = None
):
    """Get aggregated metrics for partial filters"""
    try:
        df = await data_service.load_master_dataset()
        if df is None or df.empty:
            return {
                "avg_max_buying_price": 0,
                "avg_min_selling_price": 0,
                "total_weight": 0,
                "total_products": 0
            }
        
        # Apply filters
        filtered_df = df.copy()
        if month:
            filtered_df = filtered_df[filtered_df['Month'] == month]
        if year:
            filtered_df = filtered_df[filtered_df['Year'] == year]
        if shape:
            filtered_df = filtered_df[filtered_df['Shape key'] == shape]
        if color:
            filtered_df = filtered_df[filtered_df['Color Key'] == color]
        if bucket:
            filtered_df = filtered_df[filtered_df['Buckets'] == bucket]
        
        if filtered_df.empty:
            return {
                "avg_max_buying_price": 0,
                "avg_min_selling_price": 0,
                "total_weight": 0,
                "total_products": 0
            }
        
        return {
            "avg_max_buying_price": float(filtered_df['Max Buying Price'].mean()),
            "avg_min_selling_price": float(filtered_df['Min Selling Price'].mean()),
            "total_weight": float(filtered_df['Weight'].sum()),
            "total_products": int(len(filtered_df))
        }
    except Exception as e:
        logger.error(f"Error calculating aggregated metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )