import pandas as pd
import numpy as np
from typing import Dict, Optional, List, Any
from datetime import datetime
import logging
import joblib
from pathlib import Path
import calendar
from utils.constants import stock_bucket, month_map, color_map

logger = logging.getLogger(__name__)

def apply_data_filters(df):
    """
    Apply consistent data filters to remove unwanted rows.
    This function ensures all data displayed or downloaded follows the same filtering rules.
    
    Filters applied:
    1. Remove rows where Color = 'U-V', 'S-T', 'Fancy Deep Yellow'
    2. Remove rows where Weight < 0.5
    3. Remove rows where Shape key = 'Other'
    """
    if df is None or df.empty:
        return df
    
    try:
        original_count = len(df)
        
        # Apply filters
        if 'Color' in df.columns:
            df = df[~(df['Color'] == 'U-V')]
            df = df[~(df['Color'] == 'S-T')]
            df = df[~(df['Color'] == 'Fancy Deep Yellow')]
        if 'Weight' in df.columns:
            df = df[~(df['Weight'] < 0.5)]
        if 'Shape key' in df.columns:
            df = df[~(df['Shape key'] == 'Other')]
            
        # Reset index after filtering
        df = df.reset_index(drop=True)
        
        filtered_count = len(df)
        if original_count != filtered_count:
            logger.info(f"Data filtering: {original_count} -> {filtered_count} rows ({original_count - filtered_count} rows removed)")
        
        return df
        
    except Exception as e:
        logger.error(f"Error applying data filters: {e}")
        return df

def create_color_key(df, color_map):
    """Create color key with error handling"""
    try:
        df['Color Key'] = df.Color.map(lambda x: color_map.get(x, '') if pd.notna(x) else '')
        return df
    except Exception as e:
        logger.error(f"Error creating color key: {e}")
        return df

def create_bucket(df, stock_bucket=stock_bucket):
    """Create bucket with enhanced error handling"""
    try:
        df['Buckets'] = None
        for key, values in stock_bucket.items():
            lower_bound, upper_bound = values
            mask = (df['Weight'] >= lower_bound) & (df['Weight'] < upper_bound)
            df.loc[mask, 'Buckets'] = key
        return df
    except Exception as e:
        logger.error(f"Error creating buckets: {e}")
        return df

def calculate_avg(df):
    """Calculate average with error handling"""
    try:
        df['Avg Cost Total'] = df['Weight'] * df['Average\nCost\n(USD)']
        return df
    except Exception as e:
        logger.error(f"Error calculating average: {e}")
        return df

def create_date_join(df):
    """Create date join with error handling"""
    try:
        df['Month'] = pd.to_datetime('today').month_name()
        df['Year'] = pd.to_datetime('today').year
        df['Join'] = df['Month'].astype(str) + '-' + df['Year'].map(lambda x: x-2000).astype(str)
        return df
    except Exception as e:
        logger.error(f"Error creating date join: {e}")
        return df

def concatenate_first_two_rows(df):
    """Concatenate first two rows with error handling"""
    try:
        result = {}
        for col in df.columns:
            value1 = str(df.iloc[0][col]) if not pd.isna(df.iloc[0][col]) else ''
            value2 = str(df.iloc[1][col]) if not pd.isna(df.iloc[1][col]) else ''
            result[col] = f"{value1}_{value2}"
        return result
    except Exception as e:
        logger.error(f"Error concatenating rows: {e}")
        return {}

def safe_divide(numerator, denominator, default=0):
    """Safely divide numbers, handling zero division"""
    try:
        if denominator == 0 or pd.isna(denominator) or pd.isna(numerator):
            return default
        return numerator / denominator
    except:
        return default

def populate_max_qty(df, MONTHLY_STOCK_DATA):
    """Populate max qty with enhanced error handling"""
    try:
        columns = list(concatenate_first_two_rows(df.iloc[0:2, 2:]).values())
        columns = ['Months', 'Buckets'] + columns
        df.columns = columns
        df = df.iloc[2:, :]
        df.reset_index(drop=True, inplace=True)
        
        _MAX_QTY_ = []
        MONTHLY_STOCK_DATA['Max Qty'] = None
        
        for indx, row in MONTHLY_STOCK_DATA.iterrows():
            try:
                join = row['Join']
                Shape = row['Shape key']
                Color = row['Color Key']
                Bucket = row['Buckets']
                
                if pd.isna(Color) or pd.isna(Shape) or pd.isna(Bucket):
                    value = 0
                else:
                    col_name = f"{Shape}_{Color}"
                    if col_name in df.columns.tolist():
                        filtered_df = df[(df['Months'] == join) & (df['Buckets'] == Bucket)]
                        if not filtered_df.empty and col_name in filtered_df.columns:
                            value = filtered_df[col_name].iloc[0]
                        else:
                            value = 0
                    else:
                        value = 0
                _MAX_QTY_.append(value)
            except Exception as e:
                logger.error(f"Error processing max qty for row {indx}: {e}")
                _MAX_QTY_.append(0)
        
        MONTHLY_STOCK_DATA['Max Qty'] = _MAX_QTY_
        MONTHLY_STOCK_DATA['Max Qty'] = MONTHLY_STOCK_DATA['Max Qty'].apply(
            lambda x: x[0] if isinstance(x, list) and len(x) > 0 else (x if pd.notna(x) else 0)
        )
        return MONTHLY_STOCK_DATA
    except Exception as e:
        logger.error(f"Error populating max qty: {e}")
        MONTHLY_STOCK_DATA['Max Qty'] = 0
        return MONTHLY_STOCK_DATA

def populate_min_qty(df, MONTHLY_STOCK_DATA):
    """Populate min qty with enhanced error handling"""
    try:
        columns = list(concatenate_first_two_rows(df.iloc[0:2, 2:]).values())
        columns = ['Months', 'Buckets'] + columns
        df.columns = columns
        df = df.iloc[2:, :]
        df.reset_index(drop=True, inplace=True)
        
        _MIN_QTY_ = []
        MONTHLY_STOCK_DATA['Min Qty'] = None
        
        for _, row in MONTHLY_STOCK_DATA.iterrows():
            try:
                join = row['Join']
                Shape = row['Shape key']
                Color = row['Color Key']
                Bucket = row['Buckets']
                
                if pd.isna(Color) or pd.isna(Shape) or pd.isna(Bucket):
                    value = 0
                else:
                    col_name = f"{Shape}_{Color}"
                    if col_name in df.columns.tolist():
                        filtered_df = df[(df['Months'] == join) & (df['Buckets'] == Bucket)]
                        if not filtered_df.empty and col_name in filtered_df.columns:
                            value = filtered_df[col_name].iloc[0]
                        else:
                            value = 0
                    else:
                        value = 0
                _MIN_QTY_.append(value)
            except Exception as e:
                logger.error(f"Error processing min qty: {e}")
                _MIN_QTY_.append(0)
        
        MONTHLY_STOCK_DATA['Min Qty'] = _MIN_QTY_
        MONTHLY_STOCK_DATA['Min Qty'] = MONTHLY_STOCK_DATA['Min Qty'].apply(
            lambda x: x[0] if isinstance(x, list) and len(x) > 0 else (x if pd.notna(x) else 0)
        )
        return MONTHLY_STOCK_DATA
    except Exception as e:
        logger.error(f"Error populating min qty: {e}")
        MONTHLY_STOCK_DATA['Min Qty'] = 0
        return MONTHLY_STOCK_DATA

def populate_selling_prices(df, MONTHLY_STOCK_DATA):
    """Populate selling prices with enhanced error handling"""
    try:
        columns = list(concatenate_first_two_rows(df.iloc[0:2, 1:]).values())
        columns = ['Buckets'] + columns
        df.columns = columns
        df = df.iloc[2:, :]
        df.reset_index(drop=True, inplace=True)
        
        _SELLING_PRICE_ = []
        MONTHLY_STOCK_DATA['Min Selling Price'] = None
        
        for indx, row in MONTHLY_STOCK_DATA.iterrows():
            try:
                Shape = row['Shape key']
                Color = row['Color Key']
                Bucket = row['Buckets']
                
                if pd.isna(Color) or pd.isna(Shape) or pd.isna(Bucket):
                    value = 0
                else:
                    col_name = f"{Shape}_{Color}"
                    if col_name in df.columns.tolist():
                        filtered_df = df[df['Buckets'] == Bucket]
                        if not filtered_df.empty and col_name in filtered_df.columns:
                            value = filtered_df[col_name].iloc[0]
                        else:
                            value = 0
                    else:
                        value = 0
                _SELLING_PRICE_.append(value)
            except Exception as e:
                logger.error(f"Error processing selling price: {e}")
                _SELLING_PRICE_.append(0)
        
        MONTHLY_STOCK_DATA['Min Selling Price'] = _SELLING_PRICE_
        MONTHLY_STOCK_DATA['Min Selling Price'] = MONTHLY_STOCK_DATA['Min Selling Price'].apply(
            lambda x: x[0] if isinstance(x, list) and len(x) > 0 else (x if pd.notna(x) else 0)
        )
        
        # Safe multiplication
        MONTHLY_STOCK_DATA['Min Selling Price'] = (
            MONTHLY_STOCK_DATA['Max Buying Price'].fillna(0) * 
            MONTHLY_STOCK_DATA['Min Selling Price'].fillna(0)
        )
        return MONTHLY_STOCK_DATA
    except Exception as e:
        logger.error(f"Error populating selling prices: {e}")
        MONTHLY_STOCK_DATA['Min Selling Price'] = 0
        return MONTHLY_STOCK_DATA

def populate_buying_prices(df, MONTHLY_STOCK_DATA):
    """Populate buying prices with enhanced error handling"""
    try:
        columns = list(concatenate_first_two_rows(df.iloc[0:2, 2:]).values())
        columns = ['Months', 'Buckets'] + columns
        df.columns = columns
        df = df.iloc[2:, :]
        df.reset_index(drop=True, inplace=True)
        
        _BUYING_PRICE_ = []
        MONTHLY_STOCK_DATA['Max Buying Price'] = None
        
        for indx, row in MONTHLY_STOCK_DATA.iterrows():
            try:
                join = row['Join']
                Shape = row['Shape key']
                Color = row['Color Key']
                Bucket = row['Buckets']
                
                if pd.isna(Color) or pd.isna(Shape) or pd.isna(Bucket):
                    value = 0
                else:
                    col_name = f"{Shape}_{Color}"
                    if col_name in df.columns.tolist():
                        filtered_df = df[(df['Months'] == join) & (df['Buckets'] == Bucket)]
                        if not filtered_df.empty and col_name in filtered_df.columns:
                            value = filtered_df[col_name].iloc[0]
                        else:
                            value = 0
                    else:
                        value = 0
                _BUYING_PRICE_.append(value)
            except Exception as e:
                logger.error(f"Error processing buying price: {e}")
                _BUYING_PRICE_.append(0)
        
        MONTHLY_STOCK_DATA['Max Buying Price'] = _BUYING_PRICE_
        MONTHLY_STOCK_DATA['Max Buying Price'] = MONTHLY_STOCK_DATA['Max Buying Price'].apply(
            lambda x: x[0] if isinstance(x, list) and len(x) > 0 else (x if pd.notna(x) else 0)
        )
        return MONTHLY_STOCK_DATA
    except Exception as e:
        logger.error(f"Error populating buying prices: {e}")
        MONTHLY_STOCK_DATA['Max Buying Price'] = 0
        return MONTHLY_STOCK_DATA

def calculate_buying_price_avg(df):
    """Calculate buying price average with error handling"""
    try:
        df['Buying Price Avg'] = df['Max Buying Price'].fillna(0) * df['Weight'].fillna(0)
        return df
    except Exception as e:
        logger.error(f"Error calculating buying price avg: {e}")
        df['Buying Price Avg'] = 0
        return df

def get_quarter(month):
    """Get quarter with error handling"""
    try:
        Quarter_Month_Map = {
            'Q1': ['January', 'February', 'March'],
            'Q2': ['April', 'May', 'June'],
            'Q3': ['July', 'August', 'September'],
            'Q4': ['October', 'November', 'December']
        }
        year = pd.to_datetime('today').year
        yr = year - 2000

        if month in Quarter_Month_Map['Q1']:
            return f'Q1-{yr}'
        elif month in Quarter_Month_Map['Q2']:
            return f'Q2-{yr}'
        elif month in Quarter_Month_Map['Q3']:
            return f'Q3-{yr}'
        elif month in Quarter_Month_Map['Q4']:
            return f'Q4-{yr}'
        else:
            return None
    except Exception as e:
        logger.error(f"Error getting quarter for month {month}: {e}")
        return None

def populate_quarter(df):
    """Populate quarter with error handling"""
    try:
        df['Quarter'] = df['Month'].apply(get_quarter)
        return df
    except Exception as e:
        logger.error(f"Error populating quarter: {e}")
        df['Quarter'] = None
        return df

def create_shape_key(x):
    """Create shape key with error handling"""
    try:
        if pd.isna(x):
            return 'Other'
        
        x_upper = str(x).upper()
        if 'HEART' in x_upper:
            return 'Other'
        elif 'CUSHION' in x_upper:
            return 'Cushion'
        elif 'OVAL' in x_upper:
            return 'Oval'
        elif 'PEAR' in x_upper:
            return 'Pear'
        elif 'CUT-CORNERED' in x_upper:
            return 'Radiant'
        elif 'MODIFIED RECTANGULAR' in x_upper:
            return 'Cushion'
        elif 'MODIFIED SQUARE' in x_upper:
            return 'Cushion'
        elif 'MARQUISE MODIFIED' in x_upper:
            return 'Other'
        elif 'ROUND_CORNERED' in x_upper:
            return 'Cushion'
        elif 'EMERALD' in x_upper:
            return 'Other'
        else:
            return 'Other'
    except Exception as e:
        logger.error(f"Error creating shape key for {x}: {e}")
        return 'Other'

def update_max_qty(df_max_qty, json_data_name='max_qty.pkl'): 
    """Update max qty with enhanced error handling"""
    try:
        json_data_name = f"src/{json_data_name}"
        try:
            json_data = joblib.load(json_data_name)
        except:
            json_data = {}
            
        columns = list(concatenate_first_two_rows(df_max_qty.iloc[0:2, 2:]).values())
        columns = ['Months', 'Buckets'] + columns
        df_max_qty.columns = columns
        df_max_qty = df_max_qty.iloc[2:, :]
        json_data = {}
        
        for col in df_max_qty.columns[2:]:
            json_data[col] = {}
            for month in df_max_qty['Months'].unique():
                json_data[col][month] = {}
                for bucket in df_max_qty['Buckets'].unique():
                    filtered_data = df_max_qty[
                        (df_max_qty['Months'] == month) & 
                        (df_max_qty['Buckets'] == bucket)
                    ]
                    if not filtered_data.empty:
                        json_data[col][month][bucket] = filtered_data[col].iloc[0]
                    else:
                        json_data[col][month][bucket] = 0
        
        # Ensure src directory exists
        Path("src").mkdir(exist_ok=True)
        joblib.dump(json_data, json_data_name)
        
    except Exception as e:
        logger.error(f"Error updating max qty: {e}")

def calculate_qoq_variance_percentage(current_quarter_price, previous_quarter_price):
    """Calculate QoQ variance with enhanced error handling"""
    try:
        if not isinstance(current_quarter_price, (int, float)) or not isinstance(previous_quarter_price, (int, float)):
            return 0.0
        
        if pd.isna(current_quarter_price) or pd.isna(previous_quarter_price):
            return 0.0
        
        if previous_quarter_price == 0:
            if current_quarter_price == 0:
                return 0.0
            else:
                return 100.0  # 100% increase from 0
        
        variance_percentage = ((current_quarter_price - previous_quarter_price) / previous_quarter_price) * 100
        
        if pd.isna(variance_percentage) or np.isinf(variance_percentage):
            return 0.0
            
        return round(variance_percentage, 2)
        
    except Exception as e:
        logger.error(f"Error calculating QoQ variance: {e}")
        return 0.0

def calculate_qoq_variance_series(price_data):
    """Calculate QoQ variance series with error handling"""
    try:
        if not price_data or len(price_data) < 2:
            return []
        
        variances = []
        for i in range(1, len(price_data)):
            variance = calculate_qoq_variance_percentage(price_data[i], price_data[i-1])
            variances.append(variance)
        
        return variances
        
    except Exception as e:
        logger.error(f"Error calculating QoQ variance series: {e}")
        return []

def monthly_variance(df, col):
    """Calculate monthly variance with enhanced error handling"""
    try:
        if df.empty or col not in df.columns:
            return pd.DataFrame()
        
        # Apply filters before analysis
        df = apply_data_filters(df)
        
        analysis = df.groupby(['Month', 'Year'], as_index=False)[col].sum()
        
        if analysis.empty:
            return pd.DataFrame()
        
        analysis['Num_Month'] = analysis['Month'].map(month_map)
        analysis.sort_values(by=['Year', 'Num_Month'], inplace=True)
        
        # Safe percentage change calculation
        analysis['Monthly_change'] = analysis[col].pct_change().fillna(0) * 100
        analysis['Monthly_change'] = analysis['Monthly_change'].replace([np.inf, -np.inf], 0)
        
        # QoQ calculation with error handling
        try:
            qoq_changes = calculate_qoq_variance_series(analysis[col].tolist())
            analysis['qaurter_change'] = [0] + qoq_changes
        except:
            analysis['qaurter_change'] = 0
        
        # Round values
        analysis['Monthly_change'] = analysis['Monthly_change'].round(2)
        analysis['qaurter_change'] = pd.Series(analysis['qaurter_change']).round(2)
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error calculating monthly variance: {e}")
        return pd.DataFrame()

def gap_analysis(max_qty, min_qty, stock_in_hand):
    """Gap analysis with error handling"""
    try:
        max_qty = float(max_qty) if pd.notna(max_qty) else 0
        min_qty = float(min_qty) if pd.notna(min_qty) else 0
        stock_in_hand = float(stock_in_hand) if pd.notna(stock_in_hand) else 0
        
        if stock_in_hand > max_qty:
            return stock_in_hand - max_qty
        elif stock_in_hand < min_qty:
            return stock_in_hand - min_qty
        else:
            return 0
            
    except Exception as e:
        logger.error(f"Error in gap analysis: {e}")
        return 0

def sort_months(months):
    """Sort months with error handling"""
    try:
        # Create mapping for both full names and abbreviations
        month_mapping = {}
        
        for i in range(1, 13):
            full_name = calendar.month_name[i]
            abbr_name = calendar.month_abbr[i]
            month_mapping[full_name] = i
            month_mapping[abbr_name] = i
            month_mapping[full_name.lower()] = i
            month_mapping[abbr_name.lower()] = i
        
        # Sort based on month order
        sorted_months = sorted(months, key=lambda month: month_mapping.get(month, 13))
        
        return sorted_months
        
    except Exception as e:
        logger.error(f"Error sorting months: {e}")
        return months  # Return original list if sorting fails