from pydantic import BaseModel, Field
from typing import Optional, List, Any, Union
from datetime import datetime

class UploadRecord(BaseModel):
    filename: str
    upload_time: str
    file_size: Optional[int] = None
    status: str
    file_id: Optional[str] = None

class UploadResponse(BaseModel):
    success: bool
    message: str
    file_id: str
    upload_record: UploadRecord

class DataFilters(BaseModel):
    month: Optional[str] = None
    year: Optional[int] = None
    shape: Optional[str] = None
    color: Optional[str] = None
    bucket: Optional[str] = None

class FilterOptions(BaseModel):
    months: List[str] = []
    years: List[int] = []
    shapes: List[str] = []
    colors: List[str] = []
    buckets: List[str] = []
    variance_columns: List[str] = []

class FilteredDataResponse(BaseModel):
    data: List[dict]
    max_buying_price: Union[int, float, str]
    current_avg_cost: Union[int, float, str]
    gap_analysis: Union[int, float]
    min_selling_price: Union[int, float]
    record_count: int

class SummaryMetrics(BaseModel):
    mom_variance: float
    mom_percent_change: float
    mom_qoq_percent_change: float

class SummaryRequest(BaseModel):
    filters: DataFilters
    variance_column: str

class TrendAnalysisRequest(BaseModel):
    shape: Optional[str] = None
    color: Optional[str] = None
    bucket: Optional[str] = None
    variance_column: Optional[str] = None
    month: Optional[str] = None
    year: Optional[int] = None

class GapSummaryRequest(BaseModel):
    month: Optional[str] = None
    year: Optional[int] = None
    shape: Optional[str] = None
    color: Optional[str] = None
    bucket: Optional[str] = None

class GapSummaryRecord(BaseModel):
    Month: str
    Year: int
    Shape: str
    Color: str
    Bucket: str
    Max_Qty: int = Field(alias="Max Qty")
    Min_Qty: int = Field(alias="Min Qty")
    Stock_in_Hand: int = Field(alias="Stock in Hand")
    GAP_Value: int = Field(alias="GAP Value")
    Status: str
    Min_Selling_Price: Optional[int] = Field(alias="Min Selling Price", default=0)
    Max_Buying_Price: Optional[int] = Field(alias="Max Buying Price", default=0)

    class Config:
        allow_population_by_field_name = True

class DownloadRequest(BaseModel):
    data_type: str  # "filtered", "master", "gap", "gap_excess", "gap_need"
    filters: Optional[DataFilters] = None

class ProcessingStatus(BaseModel):
    file_id: str
    status: str  # "processing", "completed", "failed"
    progress: Optional[int] = None
    error: Optional[str] = None
    timestamp: datetime

class AggregatedMetrics(BaseModel):
    avg_max_buying_price: float
    avg_min_selling_price: float
    total_weight: float
    total_products: int