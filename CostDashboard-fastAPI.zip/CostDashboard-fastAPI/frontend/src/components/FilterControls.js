import React, { useState, useCallback } from 'react';
import {
  Box,
  Button,
  Typography,
  LinearProgress,
  Alert,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { CloudUpload as CloudUploadIcon } from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const DropzoneBox = styled(Box)(({ theme, isDragActive }) => ({
  border: '2px dashed',
  borderColor: isDragActive ? theme.palette.primary.main : theme.palette.grey[300],
  borderRadius: theme.spacing(1),
  padding: theme.spacing(3),
  textAlign: 'center',
  cursor: 'pointer',
  backgroundColor: isDragActive ? theme.palette.action.hover : 'transparent',
  transition: 'all 0.3s ease',
  '&:hover': {
    borderColor: theme.palette.primary.main,
    backgroundColor: theme.palette.action.hover,
  },
}));


// Filter Controls Component
export const FilterControls = ({
  filters,
  varianceColumn,
  filterOptions,
  onFilterChange,
  onVarianceColumnChange,
}) => {
  const handleFilterChange = (field, value) => {
    const newFilters = { ...filters, [field]: value === 'None' ? null : value };
    onFilterChange(newFilters);
  };

  const handleVarianceChange = (value) => {
    onVarianceColumnChange(value === 'None' ? null : value);
  };

  const sortMonths = (months) => {
    const monthOrder = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months.sort((a, b) => monthOrder.indexOf(a) - monthOrder.indexOf(b));
  };

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Filter Controls
      </Typography>
      
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Month</InputLabel>
            <Select
              value={filters.month || 'None'}
              onChange={(e) => handleFilterChange('month', e.target.value)}
              label="Month"
            >
              <MenuItem value="None">None</MenuItem>
              {sortMonths(filterOptions.months || []).map((month) => (
                <MenuItem key={month} value={month}>
                  {month}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Year</InputLabel>
            <Select
              value={filters.year || 'None'}
              onChange={(e) => handleFilterChange('year', e.target.value)}
              label="Year"
            >
              <MenuItem value="None">None</MenuItem>
              {(filterOptions.years || []).sort((a, b) => b - a).map((year) => (
                <MenuItem key={year} value={year}>
                  {year}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Shape</InputLabel>
            <Select
              value={filters.shape || 'None'}
              onChange={(e) => handleFilterChange('shape', e.target.value)}
              label="Shape"
            >
              <MenuItem value="None">None</MenuItem>
              {(filterOptions.shapes || []).map((shape) => (
                <MenuItem key={shape} value={shape}>
                  {shape}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Color</InputLabel>
            <Select
              value={filters.color || 'None'}
              onChange={(e) => handleFilterChange('color', e.target.value)}
              label="Color"
            >
              <MenuItem value="None">None</MenuItem>
              {(filterOptions.colors || []).map((color) => (
                <MenuItem key={color} value={color}>
                  {color}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Bucket</InputLabel>
            <Select
              value={filters.bucket || 'None'}
              onChange={(e) => handleFilterChange('bucket', e.target.value)}
              label="Bucket"
            >
              <MenuItem value="None">None</MenuItem>
              {(filterOptions.buckets || []).map((bucket) => (
                <MenuItem key={bucket} value={bucket}>
                  {bucket}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth size="small">
            <InputLabel>Variance Column</InputLabel>
            <Select
              value={varianceColumn || 'None'}
              onChange={(e) => handleVarianceChange(e.target.value)}
              label="Variance Column"
            >
              <MenuItem value="None">None</MenuItem>
              {(filterOptions.variance_columns || []).map((column) => (
                <MenuItem key={column} value={column}>
                  {column}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
      </Grid>
    </Box>
  );
};

export default FilterControls;