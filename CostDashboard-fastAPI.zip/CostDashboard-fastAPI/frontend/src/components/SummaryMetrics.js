import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Alert,
  CircularProgress,
  Chip,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import Plot from 'react-plotly.js';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const MetricCard = styled(Card)(({ theme }) => ({
  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  color: 'white',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: theme.spacing(2),
  },
}));

const StatusChip = styled(Chip)(({ status }) => ({
  fontWeight: 'bold',
  ...(status === 'Excess' && {
    backgroundColor: '#4caf50',
    color: 'white',
  }),
  ...(status === 'Need' && {
    backgroundColor: '#f44336',
    color: 'white',
  }),
  ...(status === 'Adequate' && {
    backgroundColor: '#2196f3',
    color: 'white',
  }),
}));

// Summary Metrics Component
export const SummaryMetrics = ({
  allFiltersSelected,
  filteredData,
  summaryMetrics,
  aggregatedMetrics,
  filters,
}) => {
  if (allFiltersSelected) {
    // Detailed metrics for complete filter selection
    if (!filteredData) {
      return (
        <Box display="flex" justifyContent="center" p={3}>
          <CircularProgress />
        </Box>
      );
    }

    const formatCurrency = (value) => {
      if (typeof value === 'string') return value;
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(value || 0);
    };

    const formatNumber = (value) => {
      if (typeof value === 'string') return value;
      return (value || 0).toFixed(2);
    };

    return (
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Gap Analysis
              </Typography>
              <Typography variant="h4">
                {filteredData.gap_analysis || 0}
              </Typography>
              <Typography variant="body2">
                {filteredData.gap_analysis > 0
                  ? 'Excess'
                  : filteredData.gap_analysis < 0
                  ? 'Need'
                  : 'Adequate'}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Max Buying Price
              </Typography>
              <Typography variant="h4">
                {formatCurrency(filteredData.max_buying_price)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Min Selling Price
              </Typography>
              <Typography variant="h4">
                {formatCurrency(filteredData.min_selling_price)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Current Avg Cost
              </Typography>
              <Typography variant="h4">
                {formatCurrency(filteredData.current_avg_cost)}
              </Typography>
              <Typography variant="body2">
                90% of Sum(Avg Cost Total) / Weight
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>

        {summaryMetrics && (
          <>
            <Grid item xs={12} sm={6} md={4}>
              <MetricCard>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    MOM Variance
                  </Typography>
                  <Typography variant="h4">
                    {formatNumber(summaryMetrics.mom_variance)}%
                  </Typography>
                </CardContent>
              </MetricCard>
            </Grid>
            
            <Grid item xs={12} sm={6} md={4}>
              <MetricCard>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    MOM Percent Change
                  </Typography>
                  <Typography variant="h4">
                    {formatNumber(summaryMetrics.mom_percent_change)}%
                  </Typography>
                </CardContent>
              </MetricCard>
            </Grid>
            
            <Grid item xs={12} sm={6} md={4}>
              <MetricCard>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    MOM QoQ Change
                  </Typography>
                  <Typography variant="h4">
                    {formatNumber(summaryMetrics.mom_qoq_percent_change)}%
                  </Typography>
                </CardContent>
              </MetricCard>
            </Grid>
          </>
        )}

        {filteredData.data.length === 0 && (
          <Grid item xs={12}>
            <Alert severity="info">
              No data present for this specific filter combination
            </Alert>
          </Grid>
        )}
      </Grid>
    );
  } else {
    // Aggregated metrics for partial filter selection
    if (!aggregatedMetrics) {
      return (
        <Box display="flex" justifyContent="center" p={3}>
          <CircularProgress />
        </Box>
      );
    }

    const formatCurrency = (value) => {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(value || 0);
    };

    const formatNumber = (value) => {
      return (value || 0).toLocaleString();
    };

    return (
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Avg Max Buying Price
              </Typography>
              <Typography variant="h4">
                {formatCurrency(aggregatedMetrics.avg_max_buying_price)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Avg Min Selling Price
              </Typography>
              <Typography variant="h4">
                {formatCurrency(aggregatedMetrics.avg_min_selling_price)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Total Weight
              </Typography>
              <Typography variant="h4">
                {formatNumber(aggregatedMetrics.total_weight)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Total Products
              </Typography>
              <Typography variant="h4">
                {formatNumber(aggregatedMetrics.total_products)}
              </Typography>
            </CardContent>
          </MetricCard>
        </Grid>
      </Grid>
    );
  }
};


export default SummaryMetrics;