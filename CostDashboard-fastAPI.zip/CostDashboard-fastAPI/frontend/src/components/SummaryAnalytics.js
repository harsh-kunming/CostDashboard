import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Alert,
  CircularProgress,
  Chip,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import Plot from 'react-plotly.js';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const MetricCard = styled(Card)(({ theme }) => ({
  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  color: 'white',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: theme.spacing(2),
  },
}));

const StatusChip = styled(Chip)(({ status }) => ({
  fontWeight: 'bold',
  ...(status === 'Excess' && {
    backgroundColor: '#4caf50',
    color: 'white',
  }),
  ...(status === 'Need' && {
    backgroundColor: '#f44336',
    color: 'white',
  }),
  ...(status === 'Adequate' && {
    backgroundColor: '#2196f3',
    color: 'white',
  }),
}));

// Summary Analytics Component
export const SummaryAnalytics = ({ filters }) => {
  const [loading, setLoading] = useState(false);
  const [chartData, setChartData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchSummaryData();
  }, [filters]);

  const fetchSummaryData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/analytics/summary-charts', {
        shape: filters.shape,
        color: filters.color,
        bucket: filters.bucket,
        month: filters.month,
        year: filters.year,
      });

      const data = response.data.chart_data;
      
      if (data.error) {
        setError(data.error);
        setChartData(null);
      } else {
        setChartData(data);
      }
    } catch (error) {
      console.error('Error fetching summary data:', error);
      setError('Error loading summary data');
      setChartData(null);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  if (!chartData || !chartData.has_data) {
    return <Alert severity="info">No summary data available for selected filters.</Alert>;
  }

  // Prepare Plotly data
  const data = chartData.data;
  const nonSelected = data.filter(d => !d.is_selected);
  const selected = data.filter(d => d.is_selected);

  const colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D'];

  const traces = [];

  // Average Cost Trend
  if (nonSelected.length > 0) {
    traces.push({
      x: nonSelected.map(d => d.Date),
      y: nonSelected.map(d => d['Avg Cost Total']),
      type: 'scatter',
      mode: 'lines+markers',
      name: 'Avg Cost',
      line: { color: colors[0], width: 2 },
      marker: { size: 6 },
      showlegend: false,
      hovertemplate: '<b>%{x}</b><br>Avg Cost: $%{y:,.2f}<extra></extra>',
      xaxis: 'x',
      yaxis: 'y',
    });
  }

  if (selected.length > 0) {
    traces.push({
      x: selected.map(d => d.Date),
      y: selected.map(d => d['Avg Cost Total']),
      type: 'scatter',
      mode: 'markers',
      name: 'Selected Month',
      marker: { size: 12, color: '#ff0000', symbol: 'star' },
      showlegend: false,
      hovertemplate: '<b>%{x} (Selected)</b><br>Avg Cost: $%{y:,.2f}<extra></extra>',
      xaxis: 'x',
      yaxis: 'y',
    });
  }

  const layout = {
    title: chartData.title,
    height: 500,
    showlegend: false,
    plot_bgcolor: 'white',
    paper_bgcolor: 'white',
    xaxis: {
      title: 'Date',
      showgrid: true,
      gridwidth: 1,
      gridcolor: 'lightgray',
    },
    yaxis: {
      title: 'Average Cost ($)',
      showgrid: true,
      gridwidth: 1,
      gridcolor: 'lightgray',
    },
  };

  return (
    <Plot
      data={traces}
      layout={layout}
      style={{ width: '100%', height: '500px' }}
      config={{ responsive: true }}
    />
  );
};

export default SummaryAnalytics;