import React from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  Chip,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Divider,
  Alert,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Delete as DeleteIcon,
  History as HistoryIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Schedule as ScheduleIcon,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';

// Styled components
const StatusChip = styled(Chip)(({ status }) => ({
  fontWeight: 'bold',
  fontSize: '0.75rem',
  ...(status === 'Processed' && {
    backgroundColor: '#4caf50',
    color: 'white',
  }),
  ...(status === 'Processing' && {
    backgroundColor: '#ff9800',
    color: 'white',
  }),
  ...(status === 'Failed' && {
    backgroundColor: '#f44336',
    color: 'white',
  }),
}));

const HistoryItem = styled(ListItem)(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  borderRadius: theme.spacing(1),
  marginBottom: theme.spacing(1),
  backgroundColor: theme.palette.background.paper,
  '&:hover': {
    backgroundColor: theme.palette.action.hover,
  },
}));

// Upload History Component
export const UploadHistory = ({ history, onClearHistory }) => {
  const formatFileSize = (bytes) => {
    if (!bytes) return 'Unknown';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`;
  };

  const formatDateTime = (dateTimeString) => {
    try {
      const date = new Date(dateTimeString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    } catch {
      return dateTimeString;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Processed':
        return <CheckCircleIcon color="success" />;
      case 'Processing':
        return <ScheduleIcon color="warning" />;
      case 'Failed':
        return <ErrorIcon color="error" />;
      default:
        return <ScheduleIcon color="action" />;
    }
  };

  if (!history || history.length === 0) {
    return (
      <Box sx={{ mt: 3 }}>
        <Divider sx={{ my: 2 }} />
        <Alert severity="info" icon={<HistoryIcon />}>
          No upload history available
        </Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Divider sx={{ my: 2 }} />
      
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6" display="flex" alignItems="center" gap={1}>
          <HistoryIcon /> Recent Upload History
        </Typography>
        <Button
          size="small"
          color="error"
          variant="outlined"
          startIcon={<DeleteIcon />}
          onClick={onClearHistory}
        >
          Clear
        </Button>
      </Box>
      
      <Typography variant="body2" color="textSecondary" sx={{ mb: 2 }}>
        Last {Math.min(history.length, 10)} uploaded files
      </Typography>

      <List sx={{ maxHeight: 400, overflow: 'auto' }}>
        {history.map((record, index) => (
          <HistoryItem key={record.file_id || index} disablePadding>
            <Accordion sx={{ width: '100%', boxShadow: 'none' }}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                sx={{ 
                  minHeight: 48,
                  '& .MuiAccordionSummary-content': {
                    alignItems: 'center',
                  },
                }}
              >
                <Box display="flex" alignItems="center" gap={1} sx={{ flex: 1 }}>
                  {getStatusIcon(record.status)}
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography 
                      variant="body2" 
                      noWrap 
                      title={record.filename}
                      sx={{ fontWeight: 'medium' }}
                    >
                      {index + 1}. {record.filename}
                    </Typography>
                  </Box>
                  <StatusChip 
                    label={record.status} 
                    size="small" 
                    status={record.status}
                  />
                </Box>
              </AccordionSummary>
              
              <AccordionDetails sx={{ pt: 0 }}>
                <Box sx={{ pl: 4 }}>
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    <strong>Uploaded:</strong> {formatDateTime(record.upload_time)}
                  </Typography>
                  
                  {record.file_size && (
                    <Typography variant="body2" color="textSecondary" gutterBottom>
                      <strong>Size:</strong> {formatFileSize(record.file_size)}
                    </Typography>
                  )}
                  
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    <strong>Status:</strong> {record.status}
                  </Typography>
                  
                  {record.file_id && (
                    <Typography variant="body2" color="textSecondary" sx={{ fontFamily: 'monospace', fontSize: '0.7rem' }}>
                      <strong>ID:</strong> {record.file_id}
                    </Typography>
                  )}
                </Box>
              </AccordionDetails>
            </Accordion>
          </HistoryItem>
        ))}
      </List>
    </Box>
  );
};

export default UploadHistory;