import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Button,
  Grid,
  Alert,
  CircularProgress,
  Chip,
  ButtonGroup,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  Download as DownloadIcon,
  GetApp as GetAppIcon,
} from '@mui/icons-material';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  '&.MuiTableCell-head': {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
    fontWeight: 'bold',
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
  },
}));

const StatusChip = styled(Chip)(({ status }) => ({
  fontWeight: 'bold',
  ...(status === 'Excess' && {
    backgroundColor: '#4caf50',
    color: 'white',
  }),
  ...(status === 'Need' && {
    backgroundColor: '#f44336',
    color: 'white',
  }),
  ...(status === 'Adequate' && {
    backgroundColor: '#2196f3',
    color: 'white',
  }),
}));

const ShapeChip = styled(Chip)(({ shape }) => ({
  fontWeight: 'bold',
  ...(shape === 'Cushion' && {
    backgroundColor: '#baffc9',
    color: '#c62828',
  }),
  ...(shape === 'Oval' && {
    backgroundColor: '#bae1ff',
    color: '#c62828',
  }),
  ...(shape === 'Pear' && {
    backgroundColor: '#ffb3ba',
    color: '#c62828',
  }),
  ...(shape === 'Radiant' && {
    backgroundColor: '#ffdfba',
    color: '#c62828',
  }),
  ...(shape === 'Other' && {
    backgroundColor: '#ffffba',
    color: '#c62828',
  }),
}));



// GAP Analysis Component
export const GapAnalysis = ({ filters }) => {
  const [loading, setLoading] = useState(false);
  const [gapData, setGapData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [error, setError] = useState(null);
  const [summary, setSummary] = useState({ total: 0, excess: 0, need: 0 });

  useEffect(() => {
    fetchGapData();
  }, [filters]);

  const fetchGapData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/analytics/gap-summary', {
        month: filters.month,
        year: filters.year,
        shape: filters.shape,
        color: filters.color,
        bucket: filters.bucket,
      });

      const data = response.data || [];
      setGapData(data);
      
      // Calculate summary
      const excessCount = data.filter(item => item.Status === 'Excess').length;
      const needCount = data.filter(item => item.Status === 'Need').length;
      setSummary({
        total: data.length,
        excess: excessCount,
        need: needCount,
      });
    } catch (error) {
      console.error('Error fetching GAP data:', error);
      setError('Error loading GAP analysis data');
      setGapData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const downloadGapData = async (dataType) => {
    try {
      let filteredGapData = gapData;
      
      if (dataType === 'gap_excess') {
        filteredGapData = gapData.filter(item => item.Status === 'Excess');
      } else if (dataType === 'gap_need') {
        filteredGapData = gapData.filter(item => item.Status === 'Need');
      }

      if (filteredGapData.length === 0) {
        toast.warning(`No ${dataType.replace('gap_', '')} data available`);
        return;
      }

      const response = await api.post('/api/download/csv', 
        {
          data_type: 'gap',
          filters: filters,
        },
        {
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      const filename = `gap_summary_${dataType.replace('gap_', '')}_${timestamp}.csv`;
      
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success('GAP data downloaded successfully!');
    } catch (error) {
      console.error('Error downloading GAP data:', error);
      toast.error('Failed to download GAP data');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  const paginatedData = gapData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const hasExcessData = summary.excess > 0;
  const hasNeedData = summary.need > 0;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" gutterBottom fontWeight="bold">
          📋 GAP Summary
        </Typography>
      </Box>

      {gapData.length === 0 ? (
        <Alert severity="info">No data available for GAP analysis with current filters.</Alert>
      ) : (
        <>
          {/* Summary Statistics */}
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={4}>
              <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'primary.light', color: 'white' }}>
                <Typography variant="h4" fontWeight="bold">
                  {summary.total.toLocaleString()}
                </Typography>
                <Typography variant="body1">Total Records</Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'success.light', color: 'white' }}>
                <Typography variant="h4" fontWeight="bold">
                  {summary.excess.toLocaleString()}
                </Typography>
                <Typography variant="body1">
                  Excess Records {hasExcessData ? '(Available)' : '(No Data)'}
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'error.light', color: 'white' }}>
                <Typography variant="h4" fontWeight="bold">
                  {summary.need.toLocaleString()}
                </Typography>
                <Typography variant="body1">
                  Need Records {hasNeedData ? '(Available)' : '(No Data)'}
                </Typography>
              </Paper>
            </Grid>
          </Grid>

          {/* Download Buttons */}
          <Box display="flex" gap={1} mb={3} flexWrap="wrap">
            <Button
              variant="contained"
              startIcon={<DownloadIcon />}
              onClick={() => downloadGapData('gap')}
              size="small"
            >
              Download GAP Summary CSV
            </Button>
            <Button
              variant="contained"
              color="success"
              startIcon={<DownloadIcon />}
              onClick={() => downloadGapData('gap_excess')}
              disabled={!hasExcessData}
              size="small"
            >
              Download GAP Excess CSV {!hasExcessData && '(No Data)'}
            </Button>
            <Button
              variant="contained"
              color="error"
              startIcon={<DownloadIcon />}
              onClick={() => downloadGapData('gap_need')}
              disabled={!hasNeedData}
              size="small"
            >
              Download GAP Need CSV {!hasNeedData && '(No Data)'}
            </Button>
          </Box>

          {/* GAP Data Table */}
          <TableContainer component={Paper} sx={{ maxHeight: 600 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  <StyledTableCell>Month</StyledTableCell>
                  <StyledTableCell>Year</StyledTableCell>
                  <StyledTableCell>Shape</StyledTableCell>
                  <StyledTableCell>Color</StyledTableCell>
                  <StyledTableCell>Bucket</StyledTableCell>
                  <StyledTableCell align="right">Max Qty</StyledTableCell>
                  <StyledTableCell align="right">Min Qty</StyledTableCell>
                  <StyledTableCell align="right">Stock in Hand</StyledTableCell>
                  <StyledTableCell align="right">GAP Value</StyledTableCell>
                  <StyledTableCell>Status</StyledTableCell>
                  <StyledTableCell align="right">Min Selling Price</StyledTableCell>
                  <StyledTableCell align="right">Max Buying Price</StyledTableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData.map((row, index) => (
                  <StyledTableRow key={index}>
                    <TableCell>{row.Month}</TableCell>
                    <TableCell>{row.Year}</TableCell>
                    <TableCell>
                      <ShapeChip 
                        label={row.Shape} 
                        size="small" 
                        shape={row.Shape}
                      />
                    </TableCell>
                    <TableCell>{row.Color}</TableCell>
                    <TableCell>{row.Bucket}</TableCell>
                    <TableCell align="right">{row['Max Qty']?.toLocaleString() || 0}</TableCell>
                    <TableCell align="right">{row['Min Qty']?.toLocaleString() || 0}</TableCell>
                    <TableCell align="right">{row['Stock in Hand']?.toLocaleString() || 0}</TableCell>
                    <TableCell align="right">
                      <Typography 
                        component="span" 
                        color={row['GAP Value'] > 0 ? 'success.main' : row['GAP Value'] < 0 ? 'error.main' : 'primary.main'}
                        fontWeight="bold"
                      >
                        {row['GAP Value']?.toLocaleString() || 0}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <StatusChip 
                        label={row.Status} 
                        size="small" 
                        status={row.Status}
                      />
                    </TableCell>
                    <TableCell align="right">
                      {row['Min Selling Price'] ? `$${row['Min Selling Price'].toLocaleString()}` : '$0'}
                    </TableCell>
                    <TableCell align="right">
                      {row['Max Buying Price'] ? `$${row['Max Buying Price'].toLocaleString()}` : '$0'}
                    </TableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={gapData.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </>
      )}
    </Box>
  );
};

export default GapAnalysis;