import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Button,
  Grid,
  Alert,
  CircularProgress,
  Chip,
  ButtonGroup,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  Download as DownloadIcon,
  GetApp as GetAppIcon,
} from '@mui/icons-material';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  '&.MuiTableCell-head': {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
    fontWeight: 'bold',
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
  },
}));

const StatusChip = styled(Chip)(({ status }) => ({
  fontWeight: 'bold',
  ...(status === 'Excess' && {
    backgroundColor: '#4caf50',
    color: 'white',
  }),
  ...(status === 'Need' && {
    backgroundColor: '#f44336',
    color: 'white',
  }),
  ...(status === 'Adequate' && {
    backgroundColor: '#2196f3',
    color: 'white',
  }),
}));

const ShapeChip = styled(Chip)(({ shape }) => ({
  fontWeight: 'bold',
  ...(shape === 'Cushion' && {
    backgroundColor: '#baffc9',
    color: '#c62828',
  }),
  ...(shape === 'Oval' && {
    backgroundColor: '#bae1ff',
    color: '#c62828',
  }),
  ...(shape === 'Pear' && {
    backgroundColor: '#ffb3ba',
    color: '#c62828',
  }),
  ...(shape === 'Radiant' && {
    backgroundColor: '#ffdfba',
    color: '#c62828',
  }),
  ...(shape === 'Other' && {
    backgroundColor: '#ffffba',
    color: '#c62828',
  }),
}));

// Data Table Component
export const DataTable = ({ filters }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
  }, [filters]);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.post('/api/data/filtered', filters);
      setData(response.data.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Error loading data');
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const downloadData = async (dataType) => {
    try {
      const response = await api.post('/api/download/csv', 
        {
          data_type: dataType,
          filters: filters,
        },
        {
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      
      const contentDisposition = response.headers['content-disposition'];
      const filename = contentDisposition 
        ? contentDisposition.split('filename=')[1].replace(/"/g, '')
        : `${dataType}_data_${new Date().toISOString().slice(0, 10)}.csv`;
      
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success('Data downloaded successfully!');
    } catch (error) {
      console.error('Error downloading data:', error);
      toast.error('Failed to download data');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>;
  }

  // Get display columns
  const displayColumns = ['Product Id', 'Shape key', 'Color Key', 'Weight', 'Avg Cost Total', 
                         'Min Qty', 'Max Qty', 'Buying Price Avg', 'Max Buying Price'];
  
  const availableColumns = data.length > 0 ? 
    displayColumns.filter(col => data[0].hasOwnProperty(col)) : [];

  const paginatedData = data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" gutterBottom fontWeight="bold">
          📊 Data Table
        </Typography>
        
        <ButtonGroup variant="contained" size="small">
          <Button
            startIcon={<DownloadIcon />}
            onClick={() => downloadData('filtered')}
            disabled={data.length === 0}
          >
            Download Filtered Data
          </Button>
          <Button
            startIcon={<GetAppIcon />}
            onClick={() => downloadData('master')}
          >
            Download Master Data
          </Button>
        </ButtonGroup>
      </Box>

      {data.length === 0 ? (
        <Alert severity="info">No data available for current filters</Alert>
      ) : (
        <>
          <TableContainer component={Paper} sx={{ maxHeight: 600 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {availableColumns.map((column) => (
                    <StyledTableCell key={column}>{column}</StyledTableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData.map((row, index) => (
                  <StyledTableRow key={index}>
                    {availableColumns.map((column) => (
                      <TableCell key={column}>
                        {typeof row[column] === 'number' && column.includes('Price') 
                          ? `$${row[column].toLocaleString()}` 
                          : row[column]?.toString() || '-'}
                      </TableCell>
                    ))}
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={data.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </>
      )}
    </Box>
  );
};


export default DataTable;