import React, { useState, useCallback } from 'react';
import {
  Box,
  Button,
  Typography,
  LinearProgress,
  Alert,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { CloudUpload as CloudUploadIcon } from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import { toast } from 'react-toastify';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

// Styled components
const DropzoneBox = styled(Box)(({ theme, isDragActive }) => ({
  border: '2px dashed',
  borderColor: isDragActive ? theme.palette.primary.main : theme.palette.grey[300],
  borderRadius: theme.spacing(1),
  padding: theme.spacing(3),
  textAlign: 'center',
  cursor: 'pointer',
  backgroundColor: isDragActive ? theme.palette.action.hover : 'transparent',
  transition: 'all 0.3s ease',
  '&:hover': {
    borderColor: theme.palette.primary.main,
    backgroundColor: theme.palette.action.hover,
  },
}));

// File Upload Component
export const FileUpload = ({ onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState(null);

  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error('Only Excel files (.xlsx, .xls) are allowed');
      return;
    }

    setUploading(true);
    setProgress(0);
    setUploadStatus(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      // Upload file
      const uploadResponse = await api.post('/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setProgress(progress);
        },
      });

      if (uploadResponse.data.success) {
        const fileId = uploadResponse.data.file_id;
        
        // Poll for processing status
        await pollProcessingStatus(fileId);
        
        if (onUploadSuccess) {
          onUploadSuccess();
        }
      } else {
        throw new Error(uploadResponse.data.message || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(error.response?.data?.detail || 'Upload failed');
      setUploadStatus('error');
    } finally {
      setUploading(false);
      setProgress(0);
    }
  }, [onUploadSuccess]);

  const pollProcessingStatus = async (fileId) => {
    const maxAttempts = 60; // 5 minutes max
    let attempts = 0;

    return new Promise((resolve, reject) => {
      const checkStatus = async () => {
        try {
          attempts++;
          const response = await api.get(`/api/upload/status/${fileId}`);
          const status = response.data.status;

          if (status === 'completed') {
            setUploadStatus('success');
            resolve();
          } else if (status === 'failed') {
            setUploadStatus('error');
            reject(new Error('Processing failed'));
          } else if (attempts >= maxAttempts) {
            setUploadStatus('error');
            reject(new Error('Processing timeout'));
          } else {
            // Continue polling
            setTimeout(checkStatus, 5000); // Check every 5 seconds
          }
        } catch (error) {
          setUploadStatus('error');
          reject(error);
        }
      };

      checkStatus();
    });
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
    },
    multiple: false,
    disabled: uploading,
  });

  return (
    <Box sx={{ mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Upload Excel File
      </Typography>
      
      <DropzoneBox {...getRootProps()} isDragActive={isDragActive}>
        <input {...getInputProps()} />
        <CloudUploadIcon sx={{ fontSize: 48, color: 'primary.main', mb: 1 }} />
        <Typography variant="body1" gutterBottom>
          {isDragActive
            ? 'Drop the Excel file here...'
            : 'Drag & drop an Excel file here, or click to select'}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Supports .xlsx and .xls files
        </Typography>
      </DropzoneBox>

      {uploading && (
        <Box sx={{ mt: 2 }}>
          <LinearProgress variant="determinate" value={progress} />
          <Typography variant="body2" align="center" sx={{ mt: 1 }}>
            {progress < 100 ? `Uploading... ${progress}%` : 'Processing file...'}
          </Typography>
        </Box>
      )}

      {uploadStatus === 'success' && (
        <Alert severity="success" sx={{ mt: 2 }}>
          File uploaded and processed successfully!
        </Alert>
      )}

      {uploadStatus === 'error' && (
        <Alert severity="error" sx={{ mt: 2 }}>
          Upload or processing failed. Please try again.
        </Alert>
      )}
    </Box>
  );
};


export default FileUpload;