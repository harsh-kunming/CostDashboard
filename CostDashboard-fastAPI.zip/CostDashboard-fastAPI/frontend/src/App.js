import React, { useState, useEffect, useCallback } from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Paper,
  Alert,
  Tabs,
  Tab,
  CircularProgress,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import FileUpload from './components/FileUpload';
import FilterControls from './components/FilterControls';
import SummaryMetrics from './components/SummaryMetrics';
import DataTable from './components/DataTable';
import TrendAnalysis from './components/TrendAnalysis';
import SummaryAnalytics from './components/SummaryAnalytics';
import GapAnalysis from './components/GapAnalysis';
import UploadHistory from './components/UploadHistory';

// Styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(2),
  background: 'linear-gradient(145deg, #ffffff 0%, #f5f5f5 100%)',
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
  borderRadius: '12px',
}));

const CustomTabs = styled(Tabs)(({ theme }) => ({
  '& .MuiTab-root': {
    minHeight: 60,
    fontSize: '1.1rem',
    fontWeight: 500,
    color: '#8B00FF',
    '&.Mui-selected': {
      color: '#FF0000',
      fontWeight: 'bold',
    },
    '&:hover': {
      color: '#FF0000',
      transition: 'color 0.3s',
    },
  },
  '& .MuiTabs-indicator': {
    backgroundColor: '#FF0000',
    height: 3,
  },
}));

const TabPanel = ({ children, value, index, ...other }) => (
  <div
    role="tabpanel"
    hidden={value !== index}
    id={`tabpanel-${index}`}
    aria-labelledby={`tab-${index}`}
    {...other}
  >
    {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
  </div>
);

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000';
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
});

function App() {
  // State management
  const [masterStatus, setMasterStatus] = useState({ exists: false, record_count: 0 });
  const [filters, setFilters] = useState({
    month: null,
    year: null,
    shape: null,
    color: null,
    bucket: null,
  });
  const [varianceColumn, setVarianceColumn] = useState('Max Buying Price');
  const [filterOptions, setFilterOptions] = useState({
    months: [],
    years: [],
    shapes: [],
    colors: [],
    buckets: [],
    variance_columns: [],
  });
  const [filteredData, setFilteredData] = useState(null);
  const [summaryMetrics, setSummaryMetrics] = useState(null);
  const [aggregatedMetrics, setAggregatedMetrics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [uploadHistory, setUploadHistory] = useState([]);

  // Initialize app
  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchMasterStatus(),
        fetchFilterOptions(),
        fetchUploadHistory(),
      ]);
    } catch (error) {
      console.error('Error initializing app:', error);
      toast.error('Failed to initialize application');
    } finally {
      setLoading(false);
    }
  };

  const fetchMasterStatus = async () => {
    try {
      const response = await api.get('/api/master/status');
      setMasterStatus(response.data);
    } catch (error) {
      console.error('Error fetching master status:', error);
    }
  };

  const fetchFilterOptions = async () => {
    try {
      const response = await api.get('/api/filters');
      setFilterOptions(response.data);
    } catch (error) {
      console.error('Error fetching filter options:', error);
    }
  };

  const fetchUploadHistory = async () => {
    try {
      const response = await api.get('/api/history');
      setUploadHistory(response.data);
    } catch (error) {
      console.error('Error fetching upload history:', error);
    }
  };

  // Update data when filters change
  useEffect(() => {
    if (masterStatus.exists) {
      updateDashboardData();
    }
  }, [filters, varianceColumn, masterStatus.exists]);

  const updateDashboardData = useCallback(async () => {
    if (!masterStatus.exists) return;

    try {
      const allFiltersSelected = filters.month && filters.year && filters.shape && filters.color && filters.bucket;

      if (allFiltersSelected) {
        // Fetch detailed metrics for complete filter selection
        await Promise.all([
          fetchFilteredData(),
          fetchSummaryMetrics(),
        ]);
      } else {
        // Fetch aggregated metrics for partial filter selection
        await fetchAggregatedMetrics();
      }
    } catch (error) {
      console.error('Error updating dashboard data:', error);
    }
  }, [filters, varianceColumn, masterStatus.exists]);

  const fetchFilteredData = async () => {
    try {
      const response = await api.post('/api/data/filtered', filters);
      setFilteredData(response.data);
    } catch (error) {
      console.error('Error fetching filtered data:', error);
      setFilteredData(null);
    }
  };

  const fetchSummaryMetrics = async () => {
    try {
      const response = await api.post('/api/analytics/summary', {
        filters,
        variance_column: varianceColumn,
      });
      setSummaryMetrics(response.data);
    } catch (error) {
      console.error('Error fetching summary metrics:', error);
      setSummaryMetrics(null);
    }
  };

  const fetchAggregatedMetrics = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.month) params.append('month', filters.month);
      if (filters.year) params.append('year', filters.year);
      if (filters.shape) params.append('shape', filters.shape);
      if (filters.color) params.append('color', filters.color);
      if (filters.bucket) params.append('bucket', filters.bucket);

      const response = await api.get(`/api/aggregated-metrics?${params}`);
      setAggregatedMetrics(response.data);
    } catch (error) {
      console.error('Error fetching aggregated metrics:', error);
      setAggregatedMetrics(null);
    }
  };

  const handleUploadSuccess = async () => {
    await Promise.all([
      fetchMasterStatus(),
      fetchFilterOptions(),
      fetchUploadHistory(),
    ]);
    toast.success('File uploaded and processed successfully!');
    updateDashboardData();
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleVarianceColumnChange = (newColumn) => {
    setVarianceColumn(newColumn);
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const clearUploadHistory = async () => {
    try {
      await api.delete('/api/history');
      await fetchUploadHistory();
      toast.success('Upload history cleared successfully!');
    } catch (error) {
      console.error('Error clearing upload history:', error);
      toast.error('Failed to clear upload history');
    }
  };

  const allFiltersSelected = filters.month && filters.year && filters.shape && filters.color && filters.bucket;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h3" component="h1" gutterBottom fontWeight="bold" color="primary">
          Yellow Diamond Dashboard
        </Typography>
        <Typography variant="h6" color="textSecondary">
          Upload Excel files to process multiple sheets and filter data
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Sidebar */}
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Controls
            </Typography>
            
            {/* Master DB Status */}
            {masterStatus.exists ? (
              <Alert severity="success" sx={{ mb: 2 }}>
                Master DB: {masterStatus.record_count.toLocaleString()} records
              </Alert>
            ) : (
              <Alert severity="warning" sx={{ mb: 2 }}>
                No master database found
              </Alert>
            )}

            {/* File Upload */}
            <FileUpload onUploadSuccess={handleUploadSuccess} />

            {/* Upload History */}
            <UploadHistory 
              history={uploadHistory}
              onClearHistory={clearUploadHistory}
            />
          </StyledPaper>
        </Grid>

        {/* Main Content */}
        <Grid item xs={12} md={9}>
          {masterStatus.exists ? (
            <>
              {/* Filter Controls */}
              <StyledPaper>
                <FilterControls
                  filters={filters}
                  varianceColumn={varianceColumn}
                  filterOptions={filterOptions}
                  onFilterChange={handleFilterChange}
                  onVarianceColumnChange={handleVarianceColumnChange}
                />
              </StyledPaper>

              {/* Summary Metrics */}
              <StyledPaper>
                <Typography variant="h5" gutterBottom fontWeight="bold">
                  📊 Summary Metrics
                </Typography>
                <SummaryMetrics
                  allFiltersSelected={allFiltersSelected}
                  filteredData={filteredData}
                  summaryMetrics={summaryMetrics}
                  aggregatedMetrics={aggregatedMetrics}
                  filters={filters}
                />
                {!allFiltersSelected && (
                  <Alert severity="info" sx={{ mt: 2 }}>
                    💡 Select all filters (Month, Year, Shape, Color, and Bucket) to view detailed metrics including Gap Analysis and MOM Variance calculations.
                  </Alert>
                )}
              </StyledPaper>

              {/* Trend Analysis Tabs */}
              <StyledPaper>
                <Typography variant="h5" gutterBottom fontWeight="bold">
                  📈 Trend Analysis
                </Typography>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                  <CustomTabs value={tabValue} onChange={handleTabChange}>
                    <Tab label="📊 Variance Trends" />
                    <Tab label="📈 Summary Analytics" />
                  </CustomTabs>
                </Box>
                <TabPanel value={tabValue} index={0}>
                  <TrendAnalysis
                    filters={filters}
                    varianceColumn={varianceColumn}
                  />
                </TabPanel>
                <TabPanel value={tabValue} index={1}>
                  <SummaryAnalytics filters={filters} />
                </TabPanel>
              </StyledPaper>

              {/* Data Table */}
              <StyledPaper>
                <DataTable filters={filters} />
              </StyledPaper>

              {/* GAP Analysis */}
              <StyledPaper>
                <GapAnalysis filters={filters} />
              </StyledPaper>
            </>
          ) : (
            <StyledPaper>
              <Alert severity="info">
                No data in master database. Upload an Excel file to get started!
              </Alert>
            </StyledPaper>
          )}
        </Grid>
      </Grid>

      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </Container>
  );
}

export default App;