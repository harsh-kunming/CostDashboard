import asyncio
import logging
from pathlib import Path
import sys

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def migrate():
    """Run database migrations"""
    logger.info("Starting database migration...")
    
    # Create necessary directories
    Path("src").mkdir(exist_ok=True)
    Path("history").mkdir(exist_ok=True)
    Path("uploads").mkdir(exist_ok=True)
    Path("static").mkdir(exist_ok=True)
    
    logger.info("Migration completed successfully!")

if __name__ == "__main__":
    asyncio.run(migrate())