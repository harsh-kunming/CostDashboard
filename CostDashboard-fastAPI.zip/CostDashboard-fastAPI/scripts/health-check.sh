echo "Running health checks..."

# Check backend
echo "Checking backend..."
BACKEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/api/health)
if [ "$BACKEND_STATUS" -eq 200 ]; then
    echo "✅ Backend is healthy (HTTP $BACKEND_STATUS)"
else
    echo "❌ Backend is unhealthy (HTTP $BACKEND_STATUS)"
    exit 1
fi

# Check frontend
echo "Checking frontend..."
FRONTEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/health)
if [ "$FRONTEND_STATUS" -eq 200 ]; then
    echo "✅ Frontend is healthy (HTTP $FRONTEND_STATUS)"
else
    echo "❌ Frontend is unhealthy (HTTP $FRONTEND_STATUS)"
    exit 1
fi

echo "🎉 All services are healthy!"
