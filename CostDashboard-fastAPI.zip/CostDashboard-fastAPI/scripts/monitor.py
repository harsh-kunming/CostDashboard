import time
import requests
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def check_service(name, url):
    """Check if a service is healthy"""
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            logger.info(f"✅ {name} is healthy")
            return True
        else:
            logger.error(f"❌ {name} returned status {response.status_code}")
            return False
    except Exception as e:
        logger.error(f"❌ {name} is unreachable: {e}")
        return False

def main():
    """Monitor services continuously"""
    services = {
        "Backend": "http://localhost:8000/api/health",
        "Frontend": "http://localhost:3000/health"
    }
    
    while True:
        logger.info(f"Health check at {datetime.now()}")
        
        all_healthy = True
        for name, url in services.items():
            if not check_service(name, url):
                all_healthy = False
        
        if all_healthy:
            logger.info("🎉 All services are healthy")
        else:
            logger.warning("⚠️  Some services are unhealthy")
        
        time.sleep(60)  # Check every minute

if __name__ == "__main__":
    main()
