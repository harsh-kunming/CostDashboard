echo "Setting up Yellow Diamond Dashboard for development..."

# Create necessary directories
mkdir -p backend/{src,history,uploads,logs}
mkdir -p frontend/public
mkdir -p nginx/ssl
mkdir -p scripts
mkdir -p docs

# Backend setup
echo "Setting up Python backend..."
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Create environment file
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created backend/.env file - please update with your settings"
fi

cd ..

# Frontend setup
echo "Setting up React frontend..."
cd frontend

# Install dependencies
npm install

# Create environment file
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created frontend/.env file - please update with your settings"
fi

cd ..

echo "Setup complete!"
echo ""
echo "To start the development servers:"
echo "1. Backend: cd backend && source venv/bin/activate && python main.py"
echo "2. Frontend: cd frontend && npm start"
echo ""
echo "Or use Docker: docker-compose up --build"
